<?php
/**
 *	description:ZMAX媒体管理 ZMAX资源字段
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-12-25
 */

defined('_JEXEC') or die('You Can Not Access This File!');
JHtml::_('jquery.framework');

$this->listOrder = $this->state->get('list.ordering');
$this->listDirn = $this->state->get('list.direction');
$this->option = JRequest::getCmd('option');
$this->view = JRequest::getCmd('view');

$this->function = JRequest::getCmd('function','selectItem');
$this->extension = JRequest::getCmd('extension');

$this->docType = JRequest::getCmd('doc_type');

$doc = JFactory::getDocument();
$doc->addStyleSheet(JUri::root()."administrator/components/com_zmaxcdn/css/zmaxcdn.css");
$doc->addScript(JUri::root()."administrator/components/com_zmaxcdn/js/zmaxcdn.js");
$doc->addStyleSheet("components/com_zmaxcdn/css/zmaxcdn.css");

//$url = JUri::getInistance();
?>

<form action="" method="post" name="adminForm" id="adminForm" class="forminline" enctype="multipart/form-data">
	
	<div id="itemlist">
		<?php
			// Search tools bar
			echo JLayoutHelper::render('joomla.searchtools.default', array('view' => $this));
		?>
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-info">
				<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
			</div>
		<?php else : ?>		
			<hr class="hr-condensed" />
			<div class="items">
				<?php echo $this->loadTemplate('items');?>
			</div>
			<?php endif;?>
			
	</div>
	
	<div>
			<input type="hidden" name="task" value=""/>
			<input type="hidden" name="option" value="<?php echo $this->option;?>"/>
			<input type="hidden" name="view" value="<?php echo $this->view;?>"/>
			<input type="hidden" name="boxchecked" value="0" />
			<?php echo JHtml::_('form.token');?>
	</div>	
</form>