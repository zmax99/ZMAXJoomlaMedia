<?php
/**
 *	description:ZMAXCDN入口点文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-24
 */

defined('_JEXEC') or die('you can not access this file!');


//兼容j25 j3x
if(!defined('DS')) define('DS', DIRECTORY_SEPARATOR);

//导入Joomla控制器库
jimport('joomla.application.component.controller');

//加载帮助文件
JLoader::register('zmaxcdnHelper',dirname(__FILE__).DS.'helpers'.DS.'zmaxcdn.php');

//得到控制器实例
$controller = JControllerLegacy::getInstance('zmaxcdn');


//获得输入
$jinput = JFactory::getApplication()->input;
$task = $jinput->get('task',"",'STR');


//执行任务
$controller->execute($task);

//进行重定向
$controller->redirect();
