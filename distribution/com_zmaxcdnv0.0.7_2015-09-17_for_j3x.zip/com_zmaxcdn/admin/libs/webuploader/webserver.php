<?php
/**
 *	description:ZMAX CDN webuplaoder�������˿���
 *  author��min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:�����г����������Ƽ��������ι�˾��������Ȩ��
 *  date:2015-09-11
 */
defined('_JEXEC') or die('');

class zmaxcdnWebserver {
	protected $bLog = false;
	protected $file = null;
	protected $maxTime = 5;
	protected $tempFileMaxAge = 10;
	protected $uploadDir = "../media/zmaxcdn/";
	protected $cleanupTargetDir=true;	
	public $error =null;
	public $fileInfo = array();
	
	public function enableLog()
	{
		$this->bLog = true;
	}
	public function disableLog()
	{
		$this->bLog = false;
	}
	
	public function __construct()
	{
		$this->file = fopen("components/com_zmaxcdn/libs/webuploader/webupload_debug.txt","a+");
	}
	public function getFileInfo()
	{
		return $this->fileInfo;
	}
	
	public function getError()
	{
		return $this->error;
	}
	
	public function writeLog($textInfo)
	{
		if($this->bLog)
		{
			fwrite($this->file,$textInfo);
			fwrite($this->file,"\r\n");
		}
	}
	
	public function setError($message)
	{
		$this->error[] = $message;
	}
	
	
	
	
	
	public function uploadFile()
	{
		//ȷ��û�л���
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
		header("Cache-Control: no-store, no-cache, must-revalidate");
		header("Cache-Control: post-check=0, pre-check=0", false);
		header("Pragma: no-cache");
		
	
		// ֧��CORS������Դ����
		// header("Access-Control-Allow-Origin: *");
		// other CORS headers if any...
		if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') 
		{
			exit; // finish preflight CORS requests here
		}


		if ( !empty($_REQUEST[ 'debug' ]) ) 
		{
			$random = rand(0, intval($_REQUEST[ 'debug' ]) );
			if ( $random === 0 ) {
				header("HTTP/1.0 500 Internal Server Error");
				exit;
			}
		}

		$catid = $_REQUEST["catid"];
		
		@set_time_limit($this->maxTime * 60);

		// Uncomment this one to fake upload time
		// usleep(5000);

		// Settings
		//$targetDir = ini_get("upload_tmp_dir").DIRECTORY_SEPARATOR . "zmaxupload";		
		//$targetDir = ini_get("upload_tmp_dir");		
		$targetDir = "components/com_zmaxcdn/zmaxupload_temp";		
		$uploadDir = $this->uploadDir;//�ļ��ϴ������ļ���
		
		$cleanupTargetDir = $this->cleanupTargetDir; // Remove old files
		$maxFileAge = $this->tempFileMaxAge * 3600; // Temp file age in seconds


		//������ʱ�ļ���
		if (!file_exists($targetDir)) 
		{
			@mkdir($targetDir);
		}

		//����Ŀ���ļ���
		if (!file_exists($uploadDir)) 
		{
			@mkdir($uploadDir);
		}

		//����ļ�������
		if (isset($_REQUEST["name"])) {
			$fileName = $_REQUEST["name"];
		} elseif (!empty($_FILES)) {
			$fileName = $_FILES["file"]["name"];
		} else {
			$fileName = uniqid("file_");
		}
		
		//����ͻ�����ļ���������
		$filePath = $targetDir . DIRECTORY_SEPARATOR . $fileName;
		
		

		//����Ƿ������˷�Ƭ����		
		$chunk = isset($_REQUEST["chunk"]) ? intval($_REQUEST["chunk"]) : 0;
		$chunks = isset($_REQUEST["chunks"]) ? intval($_REQUEST["chunks"]) : 1;

		//����ɵ���ʱ�ļ�
		if ($cleanupTargetDir) 
		{
			if (!is_dir($targetDir) || !$dir = opendir($targetDir)) {
				echo "targetDir:".$targetDir;
				$message = "Failed to open temp directory.";
				$this->writeLog($message);
				$this->setError($message);
				die('{"jsonrpc" : "2.0", "error" : {"code": 100, "message": "Failed to open temp directory."}, "id" : "id"}');
			}

			while (($file = readdir($dir)) !== false) {
				$tmpfilePath = $targetDir . DIRECTORY_SEPARATOR . $file;

				// If temp file is current file proceed to the next
				if ($tmpfilePath == "{$filePath}_{$chunk}.part" || $tmpfilePath == "{$filePath}_{$chunk}.parttmp") {
					continue;
				}

				// Remove temp file if it is older than the max age and is not the current file
				if (preg_match('/\.(part|parttmp)$/', $file) && (@filemtime($tmpfilePath) < time() - $maxFileAge)) {
					@unlink($tmpfilePath);
				}
			}
			closedir($dir);
		}
		
		
		//��һ����ʱ�ļ�
		if (!$out = @fopen("{$filePath}_{$chunk}.parttmp", "wb")) 
		{
			$message = "Failed to open output stream";
			$this->writeLog($message);
			$this->setError($message);
			die('{"jsonrpc" : "2.0", "error" : {"code": 102, "message": "Failed to open output stream."}, "id" : "id"}');
		}
		

		//����ļ�����
		if (!empty($_FILES)) 
		{
			if ($_FILES["file"]["error"] || !is_uploaded_file($_FILES["file"]["tmp_name"])) 
			{
				$this->writeLog("Failed to move uploaded file");
				$this->setError("Failed to move uploaded file");
				die('{"jsonrpc" : "2.0", "error" : {"code": 103, "message": "Failed to move uploaded file."}, "id" : "id"}');
			}

			
			//���ļ�
			if (!$in = @fopen($_FILES["file"]["tmp_name"], "rb")) 
			{
				$this->writeLog("Failed to open input stream.");
				$this->setError("Failed to open input stream.");
				die('{"jsonrpc" : "2.0", "error" : {"code": 101, "message": "Failed to open input stream."}, "id" : "id"}');
			}
			$this->fileInfo["name"] = $_FILES["file"]["name"];
			$this->fileInfo["type"] = $_FILES["file"]["type"];
			$extName = zmaxcdnHelper::getExt($this->fileInfo["name"]);
			
			$newFileName = zmaxcdnHelper::makeName($extName,$catid);
			$uploadPath = $uploadDir . DIRECTORY_SEPARATOR .$newFileName;
			$this->fileInfo["filename"] = $newFileName;
		}
		else 
		{
			if (!$in = @fopen("php://input", "rb")) 
			{
				$message = "Failed to open input stream.";
				$this->writeLog($message);
				$this->setError($message);
				die('{"jsonrpc" : "2.0", "error" : {"code": 101, "message": "Failed to open input stream."}, "id" : "id"}');
			}
		}
		
		
		while ($buff = fread($in, 4096))
		{
			fwrite($out, $buff);
		}

		@fclose($out);
		@fclose($in);

		rename("{$filePath}_{$chunk}.parttmp", "{$filePath}_{$chunk}.part");
		
		$index = 0;
		$done = true;
		
		//��ʼ�����Ƿ����еķ�Ƭ������
		for( $index = 0; $index < $chunks; $index++ ) 
		{
			if ( !file_exists("{$filePath}_{$index}.part") ) //����Ƭ�ļ��Ƿ����
			{
				$done = false;
				break;
			}
		}
		
		//���ÿһ����Ƭ�����ڣ�˵���ϴ��ɹ��ˡ���ô��һ�����Ǻϲ��ļ���
		if ( $done ) 
		{
			if (!$out = @fopen($uploadPath, "wb")) {
				$message = "Failed to open output stream".$uploadPath;
				$this->writeLog($message);
				$this->setError($message);
				die('{"jsonrpc" : "2.0", "error" : {"code": 102, "message": "Failed to open output stream."}, "id" : "id"}');
			}
		

			if ( flock($out, LOCK_EX) ) {
				for( $index = 0; $index < $chunks; $index++ ) {
					if (!$in = @fopen("{$filePath}_{$index}.part", "rb")) {
						break;
					}

					while ($buff = fread($in, 4096)) {
						fwrite($out, $buff);
					}

					@fclose($in);
					@unlink("{$filePath}_{$index}.part");
				}

				flock($out, LOCK_UN);
			}
			@fclose($out);
			//���¼����ļ��Ĵ�С
			$handle = fopen($uploadPath,"r");
			$fstat = fstat($handle);
			$this->fileInfo["size"] = $fstat["size"];
			$this->fileInfo["done"] = true;
			$this->fileInfo["catid"] =$catid;
		}

		fclose($this->file);
	}

}
?>