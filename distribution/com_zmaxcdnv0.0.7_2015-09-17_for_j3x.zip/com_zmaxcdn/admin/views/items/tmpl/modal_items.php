<?php
/**
 *	description:ZMAXCDN 项目列表布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-24
 */
defined('_JEXEC') or die('You Can Not Access This File!');

JHtml::_('behavior.tooltip');
JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');
$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');





?>
<table class="table table-striped" >
<tr>
	<th width="20px">
		<?php echo JHtml::_('grid.checkall'); ?>
	</th>
	<?php 
		$title = JHTML::_('searchtools.sort',JText::_("文件"),'name',$listDirn,$listOrder);
		$category = JHTML::_('searchtools.sort',JText::_("分类"),'category',$listDirn,$listOrder);
		$size = JHTML::_('searchtools.sort',JText::_("大小"),'size',$listDirn,$listOrder);
		$type = JHTML::_('searchtools.sort',JText::_("类型"),'doc_type',$listDirn,$listOrder);
		$date = JHTML::_('searchtools.sort',JText::_("上传时间"),'date',$listDirn,$listOrder);
		$description = JHTML::_('searchtools.sort',JText::_("备注"),'description',$listDirn,$listOrder);
	?>
	<th> <?php echo $title;?> </th>
	<td>预览</td>
	<th> <?php echo $category;?> </th>
	<th> <?php echo $size;?> </th>
	<th> <?php echo $type;?> </th>
	<th> <?php echo $date;?></th>	
	<th> <?php echo $description;?></th>
</tr>
<?php
 $n = 0;
 foreach ($this->items as $item):
 $checked = JHTML::_('grid.id',$n,$item->id);
 $url = zmaxcdnHelper::getSourecUrl($item);
 if($item->cdn_path)
 {	
	$url = zmaxcdnHelper::getCDNUrl($item);
}
?>

<tr >
	<td><?php echo $checked;?></td>
	<td><a  class="zmaxinsert" onclick='InsertImage("<?php echo $url;?>","zmaxcdn","1");'><?php echo $item->title;?></a></td>
	<td><?php echo zmaxcdnHelper::getPreview($item);?></td>
	<td><?php echo $item->category;?></td>
	<td><?php echo zmaxcdnHelper::formatFileSize($item->size);?></td>
	<td><?php echo zmaxcdnHelper::formatDocType($item->doc_type);?></td>
	<td><?php echo  JHTML::_('date' ,$item->date , JText::_('Y-m-d'));?></td>
	<td><?php  echo $item->description;?></td>
</tr>

 <?php $n++;?>
<?php endforeach;?>
<tr>
	<td colspan="8">
		<?php  echo $this->pagination->getListFooter();?>
	</td>
</tr>
</table>
<script >
	function InsertImage( url ,srcName,isImage) 
	{
		var tag;
		tag='<img class="zmax_upload_image" src="' +url + '" alt="' + srcName + '" />';
		window.parent.jInsertEditorText(tag, 'jform_articletext');
		window.parent.SqueezeBox.close();
	}
</script>
