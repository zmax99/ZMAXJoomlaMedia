<?php
/**
 *	description:ZMAXCDN 项目列表布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-09-13
 */
defined('_JEXEC') or die('You Can Not Access This File!');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.modal');
JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');
$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$doc = JFactory::getDocument();
$doc->addStyleSheet("components/com_zmaxcdn/css/zmaxcdn.css");
?>

<form action="<?php echo JRoute::_('index.php?option=com_zmaxcdn&view=items');?>" method="post" name="adminForm" id="adminForm">
  
    <?php if (!empty( $this->sidebar)) : ?>
	<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
	</div>
	<div id="j-main-container" class="span10">
	<?php else : ?>
	<div id="j-main-container">
	<?php endif;?>

	<?php
	// Search tools bar
	echo JLayoutHelper::render('joomla.searchtools.default', array('view' => $this));
	?>
	<?php if (empty($this->items)) : ?>
		<div class="alert alert-no-items">
			<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
		</div>
	<?php else : ?>
		<table class="table table-striped" id="itemslist">
			<thead><?php echo $this->loadTemplate('items');?></thead>
		</table>
	<?php endif;?>
	</div>
	<!-- 批处理 -->	
	<?php echo $this->loadTemplate('batch'); ?>
	
	<div>
			<input type="hidden" name="task" value=""/>
			<input type="hidden" name="option" value="<?php echo $option;?>"/>
			<input type="hidden" name="view" value="<?php echo $view;?>"/>
			<input type="hidden" name="boxchecked" value="0" />
			<?php echo JHtml::_('form.token');?>
	</div>	
</form>






	
	