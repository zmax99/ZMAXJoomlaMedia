<?php
/**
 *	description:ZMAXCDN 项目列表布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-11-07
 */

 defined('_JEXEC') or die('You Can Not Access This File!');
$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');
$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$com = JRequest::getVar("com");  //这里有一个参数com
JHtml::_('behavior.framework', true);

JHtml::_('behavior.modal');
JHtml::_('bootstrap.tooltip');

/**
 *   2015-11-08
 *   如果在前台可能会出现问题。因为前台没有这个CSS。这个问题需要解决一下
 *   TO DO;
 */
 
$doc = JFactory::getDocument();
$doc->addStyleSheet("components/com_zmaxcdn/css/zmaxcdn.css");
$doc->addScript("components/com_zmaxcdn/js/zmaxcdn.js");

$app = JFactory::getApplication();

if ($app->isSite())
{
	JSession::checkToken('get') or die(JText::_('JINVALID_TOKEN'));
}
$function = JRequest::getCmd('function','selectItem');
?>
<div id="modal">
	<form action="<?php echo JRoute::_('index.php?option=com_zmaxcdn&view=items&layout=modal&tmpl=component&function='.$function.'&'.JSession::getFormToken().'=1');?>" method="post" name="adminForm" id="adminForm" class="forminline" enctype="multipart/form-data">
		<div id="j-main-container">	
			<div id="itemlist_controller" class="btn btn-primary">显示或隐藏资源列表</div>
			<?php
				echo JLayoutHelper::render('joomla.searchtools.default', array('view' => $this));
			?>
			<div id="itemlist">
				<?php if (empty($this->items)) : ?>
				
					<div class="alert alert-info alert-no-items">
						<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
					</div>
				<?php else : ?>		
				
				<hr class="hr-condensed" />
				<div class="items">
					<?php echo $this->loadTemplate('items');?>
				</div>
				<?php endif;?>
					
			</div>
			<hr class="hr-condensed"/>
			<div class="upload">
				<?php  echo $this->loadTemplate('upload');?>
			</div>
		</div>
		<div>
				<input type="hidden" name="task" value=""/>
				<input type="hidden" name="option" value="<?php echo $option;?>"/>
				<input type="hidden" name="view" value="<?php echo $view;?>"/>
				<input type="hidden" name="boxchecked" value="0" />
				<?php echo JHtml::_('form.token');?>
		</div>	
	</form>
</div>