<?php 
//加载需要的css ,js
JHtml::_('jquery.framework');
$doc = JFactory::getDocument();
$doc->addStyleSheet("components/com_zmaxcdn/libs/webuploader/wup.css");
$doc->addScript("components/com_zmaxcdn/libs/webuploader/webuploader.min.js");
$doc->addScript("components/com_zmaxcdn/libs/webuploader/wup.js");
$option = JRequest::getCmd('option');
?>

<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if (task == 'item.cancel' || document.formvalidator.isValid(document.id('item-form')))
		{
			Joomla.submitform(task, document.getElementById('item-form'));
		}
	}
</script>

<form action="<?php echo JRoute::_('index.php');?>" method="post" name="adminForm" class="form-validate" id="item-form"  enctype="multipart/form-data">
<!--------------------------------------------->
	
	<div class="page-container">
		<div class="info_head">
			<label>请选择分类</label>
			<select	name="catid" id="select_catid" class="itemcate">
				<?php $options = JHtml::_('category.options','com_zmaxcdn',$config = array('filter.published' => array(1),'filter.access' =>array(1)));?>
				<?php echo JHtml::_('select.options',$options,'value','text',"",true);?>
			</select>
		</div>
		
		<div class="wu-example" id="uploader">
			<div class="queueList">
				<div class="placeholder" id="dndArea">
					<div id="filePicker" class="webuploader-container">
						<div class="webuploader-pick">点击选择图片</div>
					</div>
					<p>或将图片或者其他类型文件拖到这里</p>
				</div>
			</div>
		</div>
<!--------------------------------------------->
	<div>
		<input type="hidden" name="option" value="<?php echo $option;?>"/>
		<input type="hidden" name="task" value=""/>
		<input type="hidden" name="id" value="" />
		<?php echo JHtml::_('form.token');?>
	</div>
</form>

<script type="text/javascript">
	// 添加全局站点信息
	var BASE_URL = '<?php echo JURI::root();?>components/com_zmaxcdn/libs/webuploader/';
	var DOMAIN_URL = '<?php echo JURI::root();?>';	
	var SERVER_URL ='index.php?option=com_zmaxcdn&task=upload.uploadItemAndInsert';
	var UPLOADER_VIEW = 'modal';
</script>
	
	