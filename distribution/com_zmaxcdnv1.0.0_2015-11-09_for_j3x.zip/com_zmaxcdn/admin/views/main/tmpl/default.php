<?php
/**
 * ZMAX CDN
 * @copyright (C) 2008 - 2015 南宁市程序人软件科技有限责任公司保留所有权利
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 **/
 
defined ( '_JEXEC' ) or die ();
$option = JRequest::getCmd('option');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

$doc = JFactory::getDocument();
$doc->addStyleSheet("components/com_zmaxcdn/css/zmaxcdn.css");
$cpInfo = $this->cpInfo;
$sysInfo = $this->sysInfo;
?>
<form action="<?php echo JRoute::_('index.php?option=com_zmaxshop');?>" method="post" name="adminForm" id="adminForm">
	<?php if (!empty( $this->sidebar)) : ?>
	<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
	</div>
	<div id="j-main-container" class="span10">
	<?php else : ?>
	<div id="j-main-container">
	<?php endif;?>
		<section>
			<div class="row-fluid">				
				<div class="span12">
					<div class="well well-small">
						<div class="module-title nav-header"><?php echo JText::_('系统信息') ?></div>
						<hr class="hr-condensed">																
						<dl class="dl-horizontal">
							<dt>编辑器按钮插件:</dt>
							<dd>
								<?php if($sysInfo->insertBtnPlg):?>
									启用
								<?php else:?>
									<font style="color:red">禁用</font>
								<?php endif;?>
							</dd>
						</dl>
						<div class="module-title nav-header"><?php echo JText::_('功能介绍') ?></div>
						<hr class="hr-condensed">												
						<dl class="dl-horizontal">
							<dt>改进系统媒体管理:</dt>
							<dd>
								本扩展可以取代Joomla系统的媒体管理。上传文件和插入文件一步到位
							</dd>
							<dt>插入文件更加容易:</dt>
							<dd>
								内置搜索功能，让你迅速定位你想要插入的资源
							</dd>
							<dt>改进系统不支持中文名称:</dt>
							<dd>
								本扩展可以支持中文名称资源(图片，视频，压缩包等等)以及任何其他字符的名称
							</dd>
							<dt>内部集成七牛CDN加速:</dt>
							<dd>
								系统会自动将你网站的静态内容同步到你的七牛空间，让你的Joomla网站飞起来！
							</dd>
							<dt>批量添加:</dt>
							<dd>
								在随后的版本中我们会实现批量添加的功能，让你不再为joomla网站插入图片而头痛
							</dd>
						</dl>		
					</div>
				</div>
			</div>
		</section>
		<section class="content-block" id="zmaxlogin" role="main">
				<div class="row-fluid">
					<div class="span7">
						<div class="well well-small">
							<div class="module-title nav-header"><?php echo JText::_('欢迎使用ZMAX CDN资源管理系统') ?></div>
							<hr class="hr-condensed">
							<div id="dashboard-icons" class="btn-group">
								
								<a class="btn" href="index.php?option=com_zmaxcdn&view=items">
									<img src="components/com_zmaxcdn/images/items.png" alt="<?php echo JText::_('资源管理') ?>" /><br/>
									<span><?php echo JText::_('资源管理') ?></span>
								</a>
								<a class="btn" href="index.php?option=com_categories&view=categories&extension=com_zmaxcdn">
									<img src="components/com_zmaxcdn/images/categories.png" alt="<?php echo JText::_('类别管理') ?>" /><br />
									<span><?php echo JText::_('类别管理') ?></span>
								</a>
								<a class="btn" href="index.php?option=com_config&view=component&component=com_zmaxcdn">
									<img src="components/com_zmaxcdn/images/shezhi.png" alt="<?php echo JText::_('系统设置') ?>" /><br />
									<span><?php echo JText::_('系统设置') ?></span>
								</a>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>

					<div class="span5">
						<div class="well well-small">
							<div class="center">
								<img src="components/com_zmaxcdn/images/zmax_logo.png" / title="ZMAX程序人，中国专业的Joomla扩展开发商!">
							</div>
							<hr class="hr-condensed">
							<dl class="dl-horizontal">
								<dt><?php echo JText::_('版本:') ?></dt>
								<dd><?php echo $cpInfo->version;?></dd>
								<dt>日期:</dt>
								<dd><?php echo $cpInfo->creationDate;?></dd>
								<dt>作者:</dt>
								<dd><a href="<?php echo $cpInfo->authorUrl;?>" target="_blank"><?php echo $cpInfo->author;?></a></dd>
								<dt>版权:</dt>
								<dd>&copy;<?php echo $cpInfo->copyright;?></dd>
								<dt>许可:</dt>
								<dd>GNU General Public License</dd>
							</dl>
						</div>
					</div>
				</div>
			</section>
		
		</div>
	<div>
		<input type="hidden" name="option" value="<?php echo $option;?>"/>
		<input type="hidden" name="task" value=""/>
		<?php echo JHtml::_('form.token');?>
	</div>
</form>
