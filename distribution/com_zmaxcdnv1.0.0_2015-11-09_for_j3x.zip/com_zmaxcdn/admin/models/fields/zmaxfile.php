<?php
/**
 *	description:ZMAX媒体管理 项目列表模型
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-11-03
 * @license GNU General Public License version 3, or later
 */
 
defined('JPATH_BASE') or die;


class JFormFieldZmaxfile extends JFormField
{
	/**
	 *	The form field type
	 */
	 
	 protected $type="zmaxfile";
	 
	 
	 /**
	  * Method to get the field input markup.
	  * 
	  * @return string The field input markup
	  */
	  protected function getInput()
	  {
		static $index = 0;
		//Load the modal behavior script
		JHtml::_('behavior.modal' ,'a.modal');
		
		$index++;
		
		//Build the script
		$script = array();
		$script[] = ' function SelectItem'.$index.'(value ,title ){';
		$script[] = '			document.id("'.$this->id.'_id").value = value;';
		//$script[] = '			document.id("'.$this->id.'_name").value = value;';
		$script[] = '			SqueezeBox.close();';
		$script[] = '			}';
		
		// Add the script to the document head
		JFactory::getDocument()->addScriptDeclaration(implode("\n" ,$script));		
		
		
		
		$extension = $this->element['extension'] ? $this->element['extension'] : "com_content";
		$docType = $this->element['doc_type'] ? $this->element['doc_type'] : ""; //返回所有


		//echo $extension;
		//echo $docType;
		
		//Setup variables for display
		$html = array();
		$link = 'index.php?option=com_zmaxcdn&amp;view=items&amp;layout=field&amp;tmpl=component&amp;function=SelectItem'.$index."&extension=".$extension."&doc_type=".$docType;
		
		$value=$this->value;
		$value = htmlspecialchars($value ,ENT_QUOTES ,'UTF-8');
		
		$html[] = '<div class="input-prepend input-append">';
		$html[] = '<div class="media-preview add-on">';
		$html[] = '<span title="" class="hasTipPreview"><span class="icon-eye"></span></span>';
		$html[] = '</div>';
		$class=' input-small hasTipImgpath ';
		if($this->required)
		{
			$class= ' class="required modal-value"';
		}
		$html[]= '<input type="text" id="'.$this->id.'_id"'.$class.' name="'.$this->name .'" value="'.$value.'" readonly="readonly" />';
		$html[] = '	<a class="modal btn" href="'.$link.'&amp;'.JSession::getFormToken().'=1" rel="{handler:\'iframe\',size:{x:800 ,y:450}}" >'.JText::_('选择项目').'</a>';
		$html[] = '<a onclick="SelectItem'.$index.'( \'\' ,\'\');return false;" href="#" title="" class="btn hasTooltip" data-original-title="清除">';
		$html[] = '<span class="icon-remove"></span></a>';
		$html[] = '</div>';
		
		
		return implode("\n" ,$html);
	  }
}