<?php
/**
 *	description:ZMAX媒体管理组件 项目列表布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-11-03
 */
defined('_JEXEC') or die('You Can Not Access This File!');

$title = JHTML::_('searchtools.sort',JText::_("文件"),'name',$this->listDirn,$this->listOrder);
$category = JHTML::_('searchtools.sort',JText::_("分类"),'category',$this->listDirn,$this->listOrder);
$size = JHTML::_('searchtools.sort',JText::_("大小"),'size',$this->listDirn,$this->listOrder);
$type = JHTML::_('searchtools.sort',JText::_("类型"),'doc_type',$this->listDirn,$this->listOrder);
$date = JHTML::_('searchtools.sort',JText::_("上传时间"),'date',$this->listDirn,$this->listOrder);
$description = JHTML::_('searchtools.sort',JText::_("备注"),'description',$this->listDirn,$this->listOrder);
?>
<table class="table table-striped" >
	<thead>
			<th> <?php echo $title;?> </th>
			<?php if($this->config->show_title_prev):?>
			<td>预览</td>
			<?php endif;?>
			
			<?php if($this->config->show_title_download):?>
			<td>下载</td>
			<?php endif;?>
			
			<?php if($this->config->show_title_category):?>
			<th> <?php echo $category;?> </th>
			<?php endif;?>
			
			<?php if($this->config->show_title_size):?>
			<th> <?php echo $size;?> </th>
			<?php endif;?>
			
			<?php if($this->config->show_title_doctype):?>
			<th> <?php echo $type;?> </th>
			<?php endif;?>
			
			<?php if($this->config->show_title_date):?>
			<th> <?php echo $date;?></th>	
			<?php endif;?>
			
			<?php if($this->config->show_title_remark):?>
			<th> <?php echo $description;?></th>		
			<?php endif;?>
	</thead>
	<tbody>
	<?php foreach ($this->items as $item):?>
		<?php 
			$url = zmaxcdnHelper::getItemPath($item);
			$preview = zmaxcdnHelper::getModalPreview($item);
			$download="不允许";
			if($this->config->allow_download)
			{
				$download='<a href="#" class="zmaxpackage" data-id="'.$item->id.'" >下载</a>';	
			}			
		?>
		<tr>
			<td><a href="javascript:void(0)" class="zmaxfield-insert" onclick="if (window.parent) window.parent.<?php echo $this->escape($this->function);?>('<?php echo $url; ?>', '<?php echo $this->escape(addslashes($item->title)); ?>' ,'<?php echo $url;?>');"><?php echo $this->escape($item->title); ?></a></td>
			<?php if($this->config->show_title_prev):?>
			<td><?php echo $preview;?></td>
			<?php endif;?>
			
			<?php if($this->config->show_title_download):?>
			<td><?php echo $download;?></td>
			<?php endif;?>
			
			<?php if($this->config->show_title_category):?>
			<td><?php echo $item->category;?></td>
			<?php endif;?>
			
			<?php if($this->config->show_title_size):?>
			<td><?php echo zmaxcdnHelper::formatFileSize($item->size);?></td>
			<?php endif;?>
			
			<?php if($this->config->show_title_doctype):?>
			<td><?php echo zmaxcdnHelper::formatDocType($item->doc_type);?></td>
			<?php endif;?>
			
			<?php if($this->config->show_title_date):?>
			<td><?php echo  JHTML::_('date' ,$item->date , JText::_('Y-m-d'));?></td>
			<?php endif;?>
			
			<?php if($this->config->show_title_remark):?>
			<td><?php  echo $item->description;?></td>
			<?php endif;?>
		</tr>
	<?php endforeach;?>
	</tbody>
</table>
<?php  echo $this->pagination->getListFooter();?>
