<?php
/**
 *	description:ZMAX媒体管理 zmaxfield字段
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-11-03
 *  重写日期： 2015-12-25
 *  重写原因：优化字段的显示效果
 *  @license GNU General Public License version 3, or later
 */
 
defined('JPATH_BASE') or die;
require_once(JPATH_ROOT."/administrator/components/com_zmaxcdn/helpers/zmaxcdn.php");

class JFormFieldZmaxfile extends JFormField
{
	 protected $type="zmaxfile";
	 
	  protected function getInput()
	  {
		static $index = 0; //主要处理在同一个页面可能会出现多个字段的问题
		
		JHtml::_('behavior.modal' ,'a.modal');
		$index++;
		
		//组件所需要JS函数，新的函数需要至少3个值，当然可以为空
		//value : 真实存在于数据库中的字符串 ,也就是资源的访问路径 【不可见】
		//title ；这个是资源的名称    【可见】
		//preview : 这个是资源的预览图片 【可见】
		
		$script = array();
		$script[] = ' SITE_URL="'.JUri::root().'"';
		$script[] = ' function SelectItem'.$index.'(value ,title  ,preview){';
		$script[] = '			document.id("'.$this->id.'").value = value;'; //设置值 value ,关键是变量
		$script[] = '			document.id("'.$this->id.'_title").value = title;'; //设置值 title
		$script[] = '			document.id("'.$this->id.'_preview").value = preview;'; //设置预览值
		$script[] = '			SqueezeBox.close();';
		$script[] = '			}';
		
		// Add the script to the document head
		JFactory::getDocument()->addScript(JUri::root()."administrator/components/com_zmaxcdn/models/fields/tip.js");	
		JFactory::getDocument()->addStyleSheet(JUri::root()."administrator/components/com_zmaxcdn/models/fields/tip.css");	
		JFactory::getDocument()->addScriptDeclaration(implode("\n" ,$script));	
		
		
		
		$extension = $this->element['extension'] ? $this->element['extension'] : "com_content";
		$docType = $this->element['doc_type'] ? $this->element['doc_type'] : ""; //返回所有
		$catid = $this->element['catid'] ? $this->element['catid'] : ""; //是否指定分类，如果没有指定，那么就返回所有的分类
		$configId = $this->element['config_id'] ? $this->element['config_id'] : ""; //是否指定分类，如果没有指定，那么就返回所有的分类
		
		
		//Setup variables for display
		$html = array();
		$link = 'index.php?option=com_zmaxcdn&amp;view=items&amp;layout=field&amp;tmpl=component&amp;function=SelectItem'.$index."&config_id=".$configId;
		
		$value=$this->value;
		$value = htmlspecialchars($value ,ENT_QUOTES ,'UTF-8');
		
		$title="";
		$preview="";
		if($value)//如果值存在
		{				
			$item = zmaxcdnHelper::loadItemByUrl($value); //获得正真的项目
			$title=$item->name;
			$preview=$value; //目前就让预览图和本图一样
		}
		
		
		$html[] = '<div class="input-prepend input-append">';
		$html[] = '<div class="media-preview add-on" >';
		$html[] = '<span title="" data="'.$this->id.'" class="zmax-hasTipPreview"><span class="icon-eye"></span></span>';
		$html[] = '</div>';
		$class=' input-small ';
		if($this->required)
		{
			$class= ' class="required modal-value"';
		}
		$html[]= '<input type="hidden" id="'.$this->id.'"'.$class.' name="'.$this->name .'" value="'.$value.'" readonly="readonly" />';
		$html[]= '<input type="text" id="'.$this->id.'_title" name="'.$this->name .'_title" value="'.$title.'" readonly="readonly" />';
		$html[]= '<input type="hidden" id="'.$this->id.'_preview" name="'.$this->name .'_preview" value="'.$preview.'" readonly="readonly" />';
		$html[] = '	<a class="modal btn" href="'.$link.'&amp;'.JSession::getFormToken().'=1" rel="{handler:\'iframe\',size:{x:800 ,y:450}}" >'.JText::_('选择项目').'</a>';
		$html[] = '<a onclick="SelectItem'.$index.'( \'\' ,\'\',\'\');return false;" href="#" title="" class="btn hasTooltip" data-original-title="清除">';
		$html[] = '<span class="icon-remove"></span></a>';
		$html[] = '</div>';
		return implode("\n" ,$html);
	  }
	  
}