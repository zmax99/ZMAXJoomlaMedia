<?php 
	/*
	//加载需要使用的库
	require_once(JPATH_COMPONENT.DS."libs".DS."vendor".DS."autoload.php");
	use Qiniu\Auth;
    use Qiniu\Storage\UploadManager;
	use Qiniu\Storage\BucketManager;
	// 设置信息
	$params = JComponentHelper::getParams("com_zmaxcdn");
	$APP_ACCESS_KEY = $params->get("accessKey");
	$APP_SECRET_KEY = $params->get("secretKey");
	$bucket = $params->get("bucket");

	//存储区块 
    
	
	//需要上传的文件
    $file = JPATH_COMPONENT.DS."libs".DS."joomlalogo.png";

	//得到一个认证对象
    $auth = new Auth($APP_ACCESS_KEY, $APP_SECRET_KEY);
    $token = $auth->uploadToken($bucket);
    $uploadManager = new UploadManager();

	//执行上传 (多次上传同一个文件不会有任何的作用)
    list($ret, $err) = $uploadManager->putFile($token, null, $file);

	
    if ($err != null) {
      echo "上传失败。错误消息：".$err->message();
    } else {
      echo "上传成功。Key：".$ret["key"];
    }
	
	echo "<pre>";
		print_r($ret);
	echo "</pre>";
	//重命名改资源
	$bm = new BucketManager($auth);
	$bm->rename($bucket ,$ret["key"] ,"zmaxtest");
	
   /*	
	//得到所有的存储空间的名称
	$bm = new BucketManager($auth);
	$buckests = $bm->buckets();
	echo "<pre>";
	print_r($buckests);
	echo "</pre>";
	
	//得到某一个存储空间中所有的文件
	$bmFiles =$bm->listFiles($bucket);
	echo "<pre>";
	print_r($bmFiles);
	echo "</pre>";
  */	
	
	
?>
<?php
/**
 *	description:ZMAX商城 项目列表布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-05-09
 */
defined('_JEXEC') or die('You Can Not Access This File!');

JHtml::_('behavior.tooltip');
JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');
$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
?>

<form action="<?php echo JRoute::_('index.php?option=com_zmaxcdn&view=items');?>" method="post" name="adminForm" id="adminForm">
  
    <?php if (!empty( $this->sidebar)) : ?>
	<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
	</div>
	<div id="j-main-container" class="span10">
	<?php else : ?>
	<div id="j-main-container">
	<?php endif;?>

	<?php
	// Search tools bar
	echo JLayoutHelper::render('joomla.searchtools.default', array('view' => $this));
	?>
	<?php if (empty($this->items)) : ?>
		<div class="alert alert-no-items">
			<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
		</div>
	<?php else : ?>
		<table class="table table-striped" id="itemslist">
			<thead><?php echo $this->loadTemplate('head');?></thead>
		</table>
	<?php endif;?>
	</div>
	<!-- 批处理 -->	
	<?php echo $this->loadTemplate('batch'); ?>
	
	<div>
			<input type="hidden" name="task" value=""/>
			<input type="hidden" name="option" value="<?php echo $option;?>"/>
			<input type="hidden" name="view" value="<?php echo $view;?>"/>
			<input type="hidden" name="boxchecked" value="0" />
			<?php echo JHtml::_('form.token');?>
	</div>	
</form>






	
	