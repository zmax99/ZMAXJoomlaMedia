<?php
/**
 *	description:ZMAX CDN 帮助类实现文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-24
 */
 
 defined('_JEXEC') or die;
 

 abstract class zmaxcdnHelper
  {
  
	static public function getUsdRate()
	{
			$params = JComponentHelper::getParams("com_zmaxcdn");
			$usdRate = $params->get("usd_rate");
			return $usdRate;
	}
	
	/**
	 * Configure the linkbar
	 */
	public static function addSubmenu($submenu)
	{
		
		JHtmlSidebar::addEntry(JText::_('控制面板'),
										'index.php?option=com_zmaxcdn&view=main',$submenu =='main');
		JHtmlSidebar::addEntry(JText::_('资源管理'),
										'index.php?option=com_zmaxcdn&view=items',$submenu == 'items');
		JHtmlSidebar::addEntry(JText::_('分类管理'),
										'index.php?option=com_categories&view=categories&extension=com_zmaxcdn',$submenu == 'categories');
        
		
		/*
		JHtmlSidebar::addEntry(JText::_('级别管理'),
										'index.php?option=com_zmaxerp&view=levels',$submenu =='levels');
		JHtmlSidebar::addEntry(JText::_('订单管理'),
										'index.php?option=com_zmaxerp&view=orders',$submenu =='orders');
		JHtmlSidebar::addEntry(JText::_('包装管理'),
										'index.php?option=com_zmaxerp&view=packages',$submenu =='packages');
		JHtmlSidebar::addEntry(JText::_('订单跟踪'),
										'index.php?option=com_zmaxerp&view=traces',$submenu =='traces');
		JHtmlSidebar::addEntry(JText::_('销量统计'),
										'index.php?option=com_zmaxerp&view=reports',$submenu =='reports');
		JHtmlSidebar::addEntry(JText::_('VIP组管理'),
										'index.php?option=com_zmaxerp&view=groupcoupons',$submenu =='groupcoupons');
		*/								
		/*										
		JHtmlSidebar::addEntry(JText::_('COM_ZMAXSHOP_HELPER_SUBMENU_USERGUIDE'),
										'index.php?option=com_zmaxshop&view=userguide',$submenu =='userguide');		
		*/
										
		// set some global property
		$document = JFactory::getDocument();
		//$document->addStyleDeclaration('.icon-48-download'.
		//								'{background-image:url(../media/com_download/images/tux-48*48.png)}');
		if($submenu == 'categories')
		{
			$document->setTitle(JText::_('COM_ZMAXSHOP_HELPER_ADMINISTRATOR_CATEGORIES_TITLE'));	
		}
	}
	
	public static function itemStateOptions()
	{
		$options	= array();
		$options[]	= JHtml::_('select.option', '有疑问', '有疑问');
		$options[]	= JHtml::_('select.option', '缺货中', '缺货中');
		$options[]	= JHtml::_('select.option', '起订量不足', '起订量不足');
		$options[]	= JHtml::_('select.option', '已采购', '已采购');
		$options[]	= JHtml::_('select.option', '已生产', '已生产');
		$options[]	= JHtml::_('select.option', '已收货', '已收货');
		$options[]	= JHtml::_('select.option', '已发货', '已发货');
		$options[]	= JHtml::_('select.option', '取消', '取消');
		$options[]	= JHtml::_('select.option', '正常', '正常');
		return $options;
	}
	
	public static function orderStateOptions()
	{
		// Build the active state filter options.
		$options	= array();
		$options[]	= JHtml::_('select.option', '0', 'COM_ZMAXSHOP_ORDER_STATE_OPTION_WFK');
		$options[]	= JHtml::_('select.option', '1', 'COM_ZMAXSHOP_ORDER_STATE_OPTION_YFK');
		$options[]	= JHtml::_('select.option', '2', 'COM_ZMAXSHOP_ORDER_STATE_OPTION_YFH');
		$options[]	= JHtml::_('select.option', '3', 'COM_ZMAXSHOP_ORDER_STATE_OPTION_WFH');
		$options[]	= JHtml::_('select.option', '4', 'COM_ZMAXSHOP_ORDER_STATE_OPTION_YWC');
		$options[]	= JHtml::_('select.option', '', 'COM_ZMAXSHOP_ORDER_STATE_OPTION_ALL');
		return $options;
	}
	
	
	
	public static function orderOptions()
	{
		// Build the active state filter options.
		$options	= array();
		$options[]	= JHtml::_('select.option', 'title', 'COM_ZMAXSHOP_ITEM_ORDERBY_OPTION_ORDERBYTITLE');
		$options[]	= JHtml::_('select.option', 'price', 'COM_ZMAXSHOP_ITEM_ORDERBY_OPTION_ORDERBYPRICE');
		$options[]	= JHtml::_('select.option', 'date', 'COM_ZMAXSHOP_ITEM_ORDERBY_OPTION_ORDERBYDATE');
		return $options;
	}
	
	public static function dateOptions()
	{
		// Build the active state filter options.
		$options	= array();
		$options[]	= JHtml::_('select.option', '1', 'COM_ZMAXSHOP_DATE_STATE_OPTION_ONE_DAY');
		$options[]	= JHtml::_('select.option', '3', 'COM_ZMAXSHOP_DATE_STATE_OPTION_THREE_DAY');
		$options[]	= JHtml::_('select.option', '7', 'COM_ZMAXSHOP_DATE_STATE_OPTION_ONE_WEEK');
		$options[]	= JHtml::_('select.option', '30', 'COM_ZMAXSHOP_DATE_STATE_OPTION_ONE_MONTH');
		$options[]	= JHtml::_('select.option', '', 'COM_ZMAXSHOP_DATE_STATE_OPTION_ALL');
		return $options;
	}
	
	public static function typeOptions()
	{
		// Build the active state filter options.
		
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		
		$query->select('DISTINCT(type) As value ,type AS text');
		$query->from('#__extensions');
		$query->order('type');
		
		$db->setQuery($query);
		$options = $db->loadObjectList();
		
		if($error = $db->getErrorMsg())
		{
			JError::raiseWarning(500,$err);
		}
		return $options;
	}
	
	public static function cateOptions()
	{
		// Build the active state filter options.
		
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		
		$query->select('DISTINCT(id) As value ,title AS text');
		$query->from('#__categories')->where("extension='com_zmaxerp'");
		$query->order('id');
		
		$db->setQuery($query);
		$options = $db->loadObjectList();
		
		if($error = $db->getErrorMsg())
		{
			JError::raiseWarning(500,$err);
		}
		return $options;
	}
	
	static public function colorOptions($color)
	{
		$options = array();
		$colors = explode(",",$color );		
		foreach($colors as $color)
		{
			$color = JText::_($color);
			$options[] = JHtml::_('select.option' ,$color ,$color);
		}
		return $options;
		
	}
	
	static public function caiLiaoOptions($caiLiao)
	{
		$options = array();
		$caiLiaos = explode(",",$caiLiao );		
		foreach($caiLiaos as $caiLiao)
		{
			$caiLiao = JText::_($caiLiao);
			$options[] = JHtml::_('select.option' ,$caiLiao ,$caiLiao);
		}
		return $options;
		
	}
		static public function baoZhuangFangShiOptions($data)
	{
		$options = array();
		$datas = explode(",",$data );		
		foreach($datas as $data)
		{
			$data = JText::_($data);
			$options[] = JHtml::_('select.option' ,$data ,$data);
		}
		return $options;
		
	}
	
	public static function formatPrice($num)
	{
		return number_format(intval($num) ,2);
	}
	
	/*
	 * 功能：将报表的发送到用户
	 * 参数: 无 Session中获得
	 *
	 */
	public static function sendEmail_reports()
	{
		$session = JFactory::getSession();
		$items= $session->get("zmaxerp.admin_reports");
		$email = $session->get("zmaxerp.admin_reports_email");
		include("../components/com_zmaxerp/helpers/email_template/reports.php");
		$content = implode("",$content);
		$subject="销量统计报表";
		return self::sendEmail($email ,$subject ,$content);
	}
	
	/*
	 * 功能：将一个产品的包装发送到用户
	 * 参数: 无 Session中获得
	 *
	 */
	public static function sendEmail_package()
	{
		$session = JFactory::getSession();
		$item = $session->get("zmaxerp.admin_package");
		include("../components/com_zmaxerp/helpers/email_template/package.php");
		$content = implode("",$content);
		$user = JFactory::getUser($item->uid);
		$subject="产品包装详情";
		return self::sendEmail($user->email ,$subject ,$content,$strAttachment);
	}
	
	
	/*
	 * 功能：将一个订单的详情发送到用户
	 * 参数: 无 Session中获得
	 *
	 */
	public static function sendEmail_order()
	{
		$session = JFactory::getSession();
		$order = $session->get("zmaxerp.admin_orderitem_order");
		$items = $session->get("zmaxerp.admin_orderitem_items");
		$email = $session->get("zmaxerp.orderitems_reports_email");
		$usdRate = self::getUsdRate();
		include("../components/com_zmaxerp/helpers/email_template/order.php");
		$content = implode("",$content);
		$user = JFactory::getUser($order->user_id);
		$subject="订单详情";
		return self::sendEmail($email ,$subject ,$content);
	}

	public static  function sendEmail($strReceiveEmail ,$strSubject ,$strBody ,$strAttachment=null )
	{
		$mailer = JFactory::getMailer();
		$config = JFactory::getConfig();
		$sender = array(
			$config->get('config.mailfrom'),
			$config->get('config.fromname')
		);
		$mailer->isHTML(true);
		$mailer->setSender($sender);
		
		$mailer->addRecipient($strReceiveEmail);
		$mailer->setSubject($strSubject);
		$mailer->setBody($strBody);
		if($strAttachment)
		{
			$mailer->addAttachment($strAttachment);
		}
		
		$send = $mailer->Send();
		if(!$send)
		{
			JError::raiseWarning(JText::_($send->__toString()));
			return false;
		}
		return true;
	}
	static public function formatNumber($number ,$point=2)
	{
		if(!is_numeric($number))
		{
			$number = 0;
		}
		return number_format($number ,$point);
	}
	
	static public function outPutImage($image)
	{
		$defaultImage = "../components/com_zmaxerp/images/nopic.jpg";
		if(!$image)
		{
			$image = $defaultImage;
		}
		$html = '<a class="modal" href="../'.$image.'" ><img class="zmaximage" src="../'.$image.'" alt="图片"/></a>';
		echo $html;
	}
	
	static public function translateOptions($data)
	{
		$options = array();
		$datas = explode(",",$data );		
		
		foreach($datas as $data)
		{
			$data = JText::_($data);
			$options[]=$data;
			
		}
		return implode(',',$options);
	}
}
?>