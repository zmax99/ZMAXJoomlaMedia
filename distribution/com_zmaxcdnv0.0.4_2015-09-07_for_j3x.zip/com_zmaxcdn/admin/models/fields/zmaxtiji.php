<?php
/**
 *	description:ZMAXERP  tiji字段的定义
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-04-26
 */
 
defined('JPATH_BASE') or die;

 class JFormFieldZmaxTiJi extends JFormFieldText
{
	/**
	 *	The form field type
	 */
	 protected $type="ZmaxTiji";
	 
	 /**
	  * Method to get the field input markup.
	  * 
	  * @return string The field input markup
	  */
	  protected function getInput()
	  {
		$script = array();
		$script[] = ' function jisuan(){'										;
		$script[] = '			strVal = document.id("'.$this->id.'").value;'	;
		$script[] = '			nums = new Array();'							;
		$script[] = '			nums = strVal.split("*");'						;
		$script[] = '			if(nums.length!=3){'							;
		$script[] = '			alert("输入错误，请检查!"); return false;}'     ;
		$script[] = '			var tiJi=1;'									;
		$script[] = '			for(i=0; i<nums.length ;i++)'					;
		$script[] = '			{'												;
		$script[] = '			  tiJi=tiJi*nums[i];'							;			
		$script[] = '			}'												;
		$script[] = '			tiJi =tiJi/1000000;'							;
		$script[] = '			value =tiJi;'									;
		$script[] = '			document.id("'.$this->id.'").value=value;'		;
		$script[] = '			}'												;
		
		// Add the script to the document head
		JFactory::getDocument()->addScriptDeclaration(implode("\n" ,$script));
	  
		$html = parent::getInput();
		$button ='<input type="button" class="btn"  value="计算" onclick="jisuan();return false;"/>';
		$html=$html.$button;
		return $html;
	  }
	  
	  
	  
	  
	  
	  
}