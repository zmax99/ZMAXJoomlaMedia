<?php
/**
 *	description:ZMAX商城入常量定义文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2014-11-22
 */
 
defined('_JEXEC') or die('Restricted access');

// 订单状态常量
define("ORDER_STATE_WFK" ,0); //用户提交订单，但是未付款
define("ORDER_STATE_YFK" ,1); //用户已付款，但是卖家没有发货
define("ORDER_STATE_YFH" ,2); //买家已付款，卖家已发货
define("ORDER_STATE_YSH" ,3); //买家已收货 
define("ORDER_STATE_YWC" ,4); //交易成功完成
define("ORDER_STATE_YQX" ,5); //交易已经取消

// 付款类型
define("PAY_TYPE_DBJY" ,0); //支付宝担保交易
define("PAY_TYPE_ZJFK" ,1); //支付宝直接付款
define("PAY_TYPE_WYZF" ,2); //网银支付

?>