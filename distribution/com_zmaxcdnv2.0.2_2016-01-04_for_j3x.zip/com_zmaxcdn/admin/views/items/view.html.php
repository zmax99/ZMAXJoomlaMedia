<?php 
/**
 *	description:ZMAX CDN 资源列表视图
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-10-26
 * @license GNU General Public License version 3, or later
 */
 
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class zmaxcdnViewItems extends JViewLegacy
{
     
     function display($tpl = null)	 
	 {
		
		if ($this->getLayout() !== 'modal' && $this->getLayout() !== 'field')
		{
			zmaxcdnHelper::addSubmenu('items');
			$this->sidebar = JHtmlSidebar::render();
		}
		
		
		$this->items = $this->get('Items');
		$this->form = $this->get('Form');
		$this->pagination =$this->get('Pagination');
		$this->state =$this->get('State');
		$this->filterForm    = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');
		
		$this->listOrder = $this->state->get('list.ordering'); //需要排序的
		$this->listDir = $this->state->get('list.direction');//需要排序的方向
		
		
		if(count($errors = $this->get('Errors')))
		{
			JError::raiseError(500, implode('<br />',$errors));
			return false;
		}
		
		
		$this->addToolBar();
		
		parent::display($tpl);
		
	 }
	 
	 /**
	  * 设置工具栏
	  * 
	  * @access protected
	  */
	  protected function addToolBar()
	  {
		JToolBarHelper::title(JText::_("ZMAX媒体管理 - 资源管理"));		
		JToolBarHelper::addNew('item.addserver',JTEXT::_("添加资源到服务器") );
		JToolBarHelper::addNew('item.addremote',JTEXT::_("添加资源到CDN") );
		JToolBarHelper::editList('item.edit');
		JToolBarHelper::deleteList('','items.delete');
		
		if (JFactory::getUser()->authorise('core.admin', 'com_zmaxcdn'))
		{
			JToolBarHelper::preferences('com_zmaxcdn');
		}
		
		//添加一个批处理按钮
		JHtml::_('bootstrap.modal', 'collapseModal');
		$title = JText::_('JTOOLBAR_BATCH');
		// Instantiate a new JLayoutFile instance and render the batch button
		$layout = new JLayoutFile('joomla.toolbar.batch');
		$dhtml = $layout->render(array('title' => $title));
		// Get the toolbar object instance
		$bar = JToolBar::getInstance('toolbar');
		$bar->appendButton('Custom', $dhtml, 'batch');
	  }
	  
}