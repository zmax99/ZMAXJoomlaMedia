<?php
/**
 *	description:ZMAX ERP 添加商品布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-03-17
 */

defined('_JEXEC') or die ('can not access this file!');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');
$option = JRequest::getCmd('option');
?>
<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if (task == 'item.cancel' || document.formvalidator.isValid(document.id('item-form')))
		{
			Joomla.submitform(task, document.getElementById('item-form'));
		}
	}
</script>

<form action="<?php echo JRoute::_('index.php?option=com_zmaxcdn&layout=edit&id='.(int)$this->item->id);?>" method="post" name="adminForm" class="form-validate" id="item-form"  enctype="multipart/form-data">
	<div class="form-horizontal">	
		<?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>
		<?php echo JHtml::_('bootstrap.addTab', 'myTab', 'general', JText::_('资源详情', true)); ?>
		<div class="row-fluid">
			<div class="span12">
				<fieldset class="adminform">
					<div class="span9">
						<?php echo $this->form->renderFieldset("itemdetail"); ?>								
					</div>
						
				</fieldset>
			</div>
		</div>
		<?php echo JHtml::_('bootstrap.endTab'); ?>
	</div>
	<div>
		<input type="hidden" name="option" value="<?php echo $option;?>"/>
		<input type="hidden" name="task" value=""/>
		<input type="hidden" name="id" value="<?php echo  $this->item->id;?>" />
		<?php echo JHtml::_('form.token');?>
	</div>
</form>
