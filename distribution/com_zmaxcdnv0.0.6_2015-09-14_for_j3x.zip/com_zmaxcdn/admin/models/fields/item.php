<?php
/**
 *	description:ZMAX商城 项目列表模型
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2014-12-12
 */
 
defined('JPATH_BASE') or die;


 class JFormFieldItem extends JFormField
{
	/**
	 *	The form field type
	 */
	 protected $type="Item";
	 
	 /**
	  * Method to get the field input markup.
	  * 
	  * @return string The field input markup
	  */
	  protected function getInput()
	  {
		//Load the modal behavior script
		JHtml::_('behavior.modal' ,'a.modal');
		
		//Build the script
		$script = array();
		$script[] = ' function SelectItem(id ,title ,catid ){';
		$script[] = '			document.id("'.$this->id.'_id").value = id;';
		$script[] = '			document.id("'.$this->id.'_name").value = title;';
		$script[] = '			SqueezeBox.close();';
		$script[] = '			}';
		
		// Add the script to the document head
		JFactory::getDocument()->addScriptDeclaration(implode("\n" ,$script));
		
		// Setup variables for display
		$html = array();
		$link = 'index.php?option=com_zmaxshop&amp;view=items&amp;layout=modal&amp;tmpl=component&amp;function=SelectItem';
		
		$db = JFactory::getDBO();
		$db->setQuery('SELECT title  FROM #__zmaxitem WHERE id ='.(int)$this->value);
		
		$title = $db->loadResult();
		
		if($error = $db->getErrorMsg())
		{
			JError::raiseWarning(500 ,$error);
		}
		
		if(empty($title))
		{
			$title = JText::_("选择一个商品");
		}
		$title = htmlspecialchars($title ,ENT_QUOTES ,'UTF-8');
		
		//The current user display field
		$html[] = '<div class="fltlft">';
		$html[] = ' <input type="text" id="'.$this->id.'_name" value="'.$title.'"disabled="disabled" size="35" />';
		$html[] = '</div>';
		
		// The user select button
		$html[] = '<div class="button2-left">';
		$html[] = ' <div class="blank">';
		$html[] = '		<a class="modal btn" title="选择一个商品" href="'.$link.'&amp;'.JSession::getFormToken().'=1" rel="{handler:\'iframe\',size:{x:800 ,y:450}}" >'.JText::_('选择项目').'</a>';
		$html[] = '	</div>';
		$html[] = '</div>';
		
		// The active article id field
		if(0 == (int)($this->value))
		{
			$value='';
		}
		else
		{
			$value=(int)$this->value;
		}
		
		// Class='required' for client side validation
		$class='';
		if($this->required)
		{
			$class= ' class="required modal-value"';
		}
		
		$html[]= '<input type="hidden" id="'.$this->id.'_id"'.$class.' name="'.$this->name .'" value="'.$value.'" />';
		
		return implode("\n" ,$html);
	  }
}