<?php
/**
 * @package     Joomla.Legacy
 * @subpackage  Form
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE
 */

defined('JPATH_PLATFORM') or die;

JFormHelper::loadFieldClass('list');

/**
 * Form Field class for the Joomla Platform.
 * Supports an HTML select list of categories
 *
 * @package     Joomla.Legacy
 * @subpackage  Form
 * @since       11.1
 */
class JFormFieldZmaxbuyer extends JFormFieldList
{
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  11.1
	 */
	public $type = 'Zmaxbuyer';

	protected function getOptions()
	{
	
		$items = $this->getBuyers();
		$options	= array();
		if(count($items) ==0)
		{
			return $options;
		}
		
		foreach($items as $item)
		{
			$options[]	= JHtml::_('select.option', $item->uid, $item->name);
		}
		return $options;
	}
	
	protected function  getBuyers()
	{
		$db =  JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select("p.uid ");
		$query->from( '#__zmaxerp_package AS p' );
		$query->leftJoin('#__users AS u ON p.uid = u.id');
		$query->select('u.name');
		$db->setQuery($query);
		$items = $db->getObjectList();
		return $items;
	}
	
	
}
