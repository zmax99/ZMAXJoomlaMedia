DROP TABLE IF EXISTS `#__zmaxcdn_item`; /*ZMAXCDN 资源表*/

CREATE TABLE IF NOT EXISTS `#__zmaxcdn_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT, /*记录的唯一ID*/
  `catid` int(11) NOT NULL DEFAULT '0',/*资源所在的分类*/
  `uid` int(11) NOT NULL DEFAULT '0',/*资源创建者的ID*/
  `name` varchar(512) NOT NULL DEFAULT '',/*资源在系统的名称*/
  `filename` varchar(512) NOT NULL DEFAULT '',/*资源原始的文件名称*/
  `description` varchar(512)  NOT NULL, /*资源简单的描述*/
  `type` varchar(10)  NOT NULL, /*文件的类型*/
  `doc_type` varchar(128)  NOT NULL, /*文件的类型*/
  `size` int(10) unsigned NOT NULL DEFAULT '0',/*文件的大小*/
  `length` varchar(256) NOT NULL DEFAULT '',/*文件的长度 针对视频文件*/
  `cdn_path` varchar(512) NOT NULL DEFAULT '',/*CDN上的地址*/
  `local_path` varchar(512) NOT NULL DEFAULT '',/*在本地服务器的路径*/
  `create_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', /*文件上传的时间*/
  `modify_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', /*文件最后修改时间*/
  `attr` text NOT NULL, /*其他的属性*/
  `access` int(11) NOT NULL DEFAULT '0',/*资源权限*/
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

