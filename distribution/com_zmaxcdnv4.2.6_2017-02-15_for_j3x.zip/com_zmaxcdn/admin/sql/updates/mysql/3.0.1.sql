/*修改表 ，在表中增加 attribs*/
ALTER TABLE `#__zmaxcdn_item` ADD attribs text NOT NULL;

