<?php
/**
 *	description:ZMAX CDN主控制文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-24
 */
 
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');
class zmaxcdnController extends JControllerLegacy
{
	protected $default_view='main';
	
	function display($cachable = false,$urlparams = false)
	{
		$input = JFactory::getApplication()->input;
		$view = $input->getCmd('view',$this->default_view);
		$input->set('view',$view);
		
	
		parent::display($cachable);
		
		//加载子菜单
		zmaxcdnHelper::addSubmenu($view);
	}	
}