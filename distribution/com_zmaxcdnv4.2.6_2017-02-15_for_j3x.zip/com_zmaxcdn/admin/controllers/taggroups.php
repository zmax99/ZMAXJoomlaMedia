<?php
/**
 *	description:ZMAX媒体管理 自定义字段组控制器
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2014-11-22
 * @license GNU General Public License version 3, or later
 */
 
 defined('_JEXEC') or die('');
jimport('joomla.application.component.controlleradmin');


 class zmaxcdnControllerTaggroups extends JControllerAdmin
 {
	 public function getModel($name = 'taggroup' ,$prefix = 'zmaxcdnModel' ,$config = array())
	 {
		return parent::getModel($name , $prefix ,$config);
	 }
	 
	 
 }	
	

?>