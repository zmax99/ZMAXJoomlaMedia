/*修改表 ，在表中增加对应的组件信息*/
ALTER TABLE `#__zmaxcdn_item` ADD extension VARCHAR(125) NOT NULL DEFAULT 'com_content';