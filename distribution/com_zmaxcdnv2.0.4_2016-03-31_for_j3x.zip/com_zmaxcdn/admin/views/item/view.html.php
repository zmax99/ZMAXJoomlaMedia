<?php 
/**
 *	description:ZMAXCDN 资源视图文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-09-09
 */
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class zmaxcdnViewItem extends JViewLegacy
{

     function display($tpl = null)	 
	 {
		//Get data from the model
		$item = $this->get('Item');
		$form = $this->get('Form');
		$isNew = ($item->id < 1);
		
		$this->item = $item;
		$this->form = $form;
		

		// Disable main menu
		JRequest::setVar('hidemainmenu' , true);
		
		
		// add toolbar
		$this->addToolBar();
		//display the template
		parent::display($tpl);
	 }
	 
	 /**
	  * 设置工具栏
	  * 
	  * @access protected
	  */
	  protected function addToolBar()
	  {
		
		JToolBarHelper::title(JText::_("ZMAX媒体管理 - 添加资源"));
		JToolBarHelper::cancel('item.cancel','返回');
		JToolBarHelper::save('item.editsave','保存');
	  }
}