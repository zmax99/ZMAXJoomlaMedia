DROP TABLE IF EXISTS `#__zmaxcdn_item`; /*ZMAXCDN 资源表*/



