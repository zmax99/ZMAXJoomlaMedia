<?php
/**
 *	description:ZMAX媒体管理组件 项目列表布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-11-03
 */
defined('_JEXEC') or die('You Can Not Access This File!');

?>
<div class="zmaxui">
	<?php foreach($this->items as $cate):?>
	<div class="zmax-down-cate">
		<h3><?php echo $cate[0]->category;?></h3>
		<div class="zmax-row">
			<?php foreach($cate as $item):?>
				<div class="zmax-col-md-6">
					<div class="col-md-6"><a href="#" class="zmaxpackage" data-id="<?php echo $item->id;?>" ><?php echo $item->title; ?></a></div>
					<div class="col-md-6"><?php echo $item->date;?></div>
				</div>
			<?php endforeach;?>
			<div class="zmax-down-cate-readmore"><a href="index.php?option=com_zmaxcdn&view=items&id=<?php echo $item->catid;?>">更多</a></div>
		</div>
	</div>
	<?php endforeach;?>
</div>
