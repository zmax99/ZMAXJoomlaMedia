<?php 
//加载需要的css ,js
$doc = JFactory::getDocument();
$doc->addStyleSheet(JUri::root()."administrator/components/com_zmaxcdn/libs/7niu/main.css");
$doc->addStyleSheet(JUri::root()."administrator/components/com_zmaxcdn/libs/7niu/highlight.css");
$doc->addScript(JUri::root()."administrator/components/com_zmaxcdn/libs/7niu/plupload.js");
$doc->addScript(JUri::root()."administrator/components/com_zmaxcdn/libs/7niu/qiniu.js");
$doc->addScript(JUri::root()."administrator/components/com_zmaxcdn/libs/7niu/ui.js");

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');
$option = JRequest::getCmd('option');

$params = JComponentHelper::getParams("com_zmaxcdn");		
$yourQiNiuDomain = $params->get("domain");
$yourQiNiuDomain = "http://".$yourQiNiuDomain."/";

?>
<div >
	<div class="wrapper">
	<div class="info_head">
		<label>请选择分类</label>
		<select	name="catid" id="select_catid" class="itemcate">
			<?php $options = JHtml::_('category.options','com_zmaxcdn',$config = array('filter.published' => array(1),'filter.access' =>array(1)));?>
			<?php echo JHtml::_('select.options',$options,'value','text',"",true);?>
		</select>
	</div>
	
	
	<div class=" wu-example">
		<div class="placeholder" style="position: relative;" id="container">
			<a style="position: relative; z-index: 1;" id="pickfiles" href="#">				
				<span class="webuploader-pick">选择文件</span>
				<p>或将图片或者其他类型文件拖到这里</p>
			</a>
		</div>
	</div>
	
</div>

<script type="text/javascript">
	// 添加全局站点信息
	var YOU_QINIU_DOMAIN = '<?php echo $yourQiNiuDomain;?>';
	/*global Qiniu */
	/*global plupload */
	/*global FileProgress */
	/*global hljs */


	jQuery(function() {
		var uploader = Qiniu.uploader({
			runtimes: 'html5,flash,html4',
			browse_button: 'pickfiles',
			container: 'container',
			drop_element: 'container',
			max_file_size: '100mb',
			flash_swf_url: 'components/com_zmaxcdn/libs/7niu/Moxie.swf',
			dragdrop: true,
			chunk_size: '4mb',
			uptoken_url: 'index.php?option=com_zmaxcdn&task=upload.getUptoken',
			domain: YOU_QINIU_DOMAIN,
			// downtoken_url: '/downtoken',
			// unique_names: true,
			// save_key: true,
			// x_vars: {
			//     'id': '1234',
			//     'time': function(up, file) {
			//         var time = (new Date()).getTime();
			//         // do something with 'time'
			//         return time;
			//     },
			// },
			auto_start: true,
			init: {
				'FilesAdded': function(up, files) {
					jQuery('table').show();
					jQuery('#success').hide();
					plupload.each(files, function(file) {
						var progress = new FileProgress(file, 'fsUploadProgress');
						progress.setStatus("等待...");
						progress.bindUploadCancel(up);
					});
				},
				'BeforeUpload': function(up, file) {
					var progress = new FileProgress(file, 'fsUploadProgress');
					var chunk_size = plupload.parseSize(this.getOption('chunk_size'));
					if (up.runtime === 'html5' && chunk_size) {
						progress.setChunkProgess(chunk_size);
					}
				},
				'UploadProgress': function(up, file) {
					var progress = new FileProgress(file, 'fsUploadProgress');
					var chunk_size = plupload.parseSize(this.getOption('chunk_size'));
					progress.setProgress(file.percent + "%", file.speed, chunk_size);
				},
				'UploadComplete': function() {
					jQuery('#success').show();
				},
				'FileUploaded': function(up, file, info) {
					var progress = new FileProgress(file, 'fsUploadProgress');
					progress.setComplete(up, info);
				},
				'Error': function(up, err, errTip) {
					jQuery('table').show();
					var progress = new FileProgress(err.file, 'fsUploadProgress');
					progress.setError();
					progress.setStatus(errTip);
				}
					// ,
					// 'Key': function(up, file) {
					//     var key = "";
					//     // do something with key
					//     return key
					// }
			}
		});

		uploader.bind('FileUploaded', function(up ,file ,info) 
		{
			try{
				var domain = up.getOption('domain');
				
				 var res = jQuery.parseJSON(info.response);
				 //alert(res.key);
				 if(res.key == undefined)
				 {
					res.key=file.name;
				 }
				 var cdnPath = domain + res.key;// 获取上传成功后的文件的Url			 
				 var name = file.name;
				 var type=file.type;
				 var size = file.size;
				 var catid = jQuery("#select_catid").val();
				 jQuery.ajax({
					type:'post',
					url:'index.php?option=com_zmaxcdn&task=upload.fieldUploadAndInsert&uploader=cdn&function=<?php echo $this->escape($this->function);?>',
					data:{
						catid:catid,
						cdnPath:cdnPath,
						name:name,
						type:type,
						size:size,
					},
					cache:false,
					success:function(data){
						eval(data);
					},
					error:function()
					{					
						alert("添加失败，Ajax异常，请联系支持团队：Email:zhang19min88@163.com");
					}		
					
			});
				 
			 
				
			 }catch(e)
			 {
				alert(e.message);
			 }
		});
		jQuery('#container').on(
			'dragenter',
			function(e) {
				e.preventDefault();
				jQuery('#container').addClass('draging');
				e.stopPropagation();
			}
		).on('drop', function(e) {
			e.preventDefault();
			jQuery('#container').removeClass('draging');
			e.stopPropagation();
		}).on('dragleave', function(e) {
			e.preventDefault();
			jQuery('#container').removeClass('draging');
			e.stopPropagation();
		}).on('dragover', function(e) {
			e.preventDefault();
			jQuery('#container').addClass('draging');
			e.stopPropagation();
		});



		jQuery('#show_code').on('click', function() {
			$('#myModal-code').modal();
			$('pre code').each(function(i, e) {
				hljs.highlightBlock(e);
			});
		});


		jQuery('body').on('click', 'table button.btn', function() {
			$(this).parents('tr').next().toggle();
		});



	});

</script>	

	
	