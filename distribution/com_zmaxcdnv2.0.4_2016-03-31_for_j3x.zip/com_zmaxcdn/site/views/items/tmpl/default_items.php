<?php
/**
 *	description:ZMAX媒体管理组件 项目列表布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-11-03
 */
defined('_JEXEC') or die('You Can Not Access This File!');

$title = JHTML::_('searchtools.sort',JText::_("文件"),'name',$this->listDirn,$this->listOrder);
$category = JHTML::_('searchtools.sort',JText::_("分类"),'category',$this->listDirn,$this->listOrder);
$size = JHTML::_('searchtools.sort',JText::_("大小"),'size',$this->listDirn,$this->listOrder);
$type = JHTML::_('searchtools.sort',JText::_("类型"),'doc_type',$this->listDirn,$this->listOrder);
$date = JHTML::_('searchtools.sort',JText::_("上传时间"),'date',$this->listDirn,$this->listOrder);
$description = JHTML::_('searchtools.sort',JText::_("说明"),'description',$this->listDirn,$this->listOrder);
?>
<div class="zmaxui">
	<table class="zmax-table zmax-table-striped" >
		<thead>
			<tr>
				<th> <?php echo $title;?> </th>				
				<th> <?php echo $category;?> </th>
				<th> <?php echo $size;?> </th>
				<th> <?php echo $date;?></th>	
				<th> <?php echo $description;?></th>
			</tr>
		</thead>
	

		<tbody>
		<?php foreach ($this->items as $item):?>
			<tr>
				<td><a href="#" class="zmaxpackage" data-id="<?php echo $item->id;?>" ><?php echo $this->escape($item->title); ?></a></td>				
				<td><?php echo $item->category;?></td>
				<td><?php echo zmaxcdnHelper::formatFileSize($item->size);?></td>				
				<td><?php echo  JHTML::_('date' ,$item->date , JText::_('Y-m-d'));?></td>
				<td><?php  echo $item->description;?></td>
			</tr>
		<?php endforeach;?>
		</tbody>
	</table>
</div>
<?php  echo $this->pagination->getListFooter();?>