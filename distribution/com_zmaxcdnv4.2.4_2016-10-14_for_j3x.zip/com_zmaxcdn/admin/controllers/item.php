<?php
/**
 *	description:ZMAX CDN 资源控制器
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2016-04-18
 *  @license GNU General Public License version 3, or later
 */
 
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');

	
class zmaxcdnControllerItem extends JControllerForm
 { 
	
	public function loadItem()
	{
		$app = JFactory::getApplication();
		$id = $app->input->get('id',"",'INT');
		if($id=="")
		{
			return null;
		}
		
		$item = zmaxcdnItemHelper::getItemById($id);
		if($item)
		{
			//$item->url  = zmaxcdnItemHelper::getItemUrl($item);
			$item->url  = zmaxcdnItemHelper::getItemValue($item);
		}
		
		echo json_encode($item);
		$app->close();
	}
	
	/**
	 * Method to run batch operations.
	 *
	 * @param   object  $model  The model.
	 *
	 * @return  boolean   True if successful, false otherwise and internal error is set.
	 *
	 * @since   1.6
	 */
	public function batch($model = null)
	{
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		// Set the model
		$model = $this->getModel('item', '', array());

		// Preset the redirect
		$this->setRedirect(JRoute::_('index.php?option=com_zmaxcdn&view=items' . $this->getRedirectToListAppend(), false));

		return parent::batch($model);
	}
 }	
	

?>