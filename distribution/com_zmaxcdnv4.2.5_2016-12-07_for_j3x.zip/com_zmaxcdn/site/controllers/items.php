<?php
/**
 *	description:ZMAX CDN 资源列表控制器
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-24
 */
 
jimport('joomla.application.component.controlleradmin');


 class zmaxcdnControllerItems extends JControllerAdmin
 {
	 public function getModel($name = 'item' ,$prefix = 'zmaxcdnModel' ,$config = array())
	 {
		return parent::getModel($name , $prefix ,$config);
	 }
	 
	 
 }	
	

?>