<?php 
//加载需要的css ,js
$doc = JFactory::getDocument();
$doc->addStyleSheet(JUri::root()."/administrator/components/com_zmaxcdn/libs/7niu/main.css");
$doc->addStyleSheet(JUri::root()."/administrator/components/com_zmaxcdn/libs/7niu/highlight.css");
$doc->addScript(JUri::root()."/administrator/components/com_zmaxcdn/libs/7niu/plupload.js");
$doc->addScript(JUri::root()."/administrator/components/com_zmaxcdn/libs/7niu/qiniu.js");
$doc->addScript(JUri::root()."/administrator/components/com_zmaxcdn/libs/7niu/ui.js");

JHtml::_('jquery.framework');
JHtml::_('behavior.keepalive');

?>
<div >
	<div class="wrapper">
	<div class="info_head">
		<?php if(!$this->config->catid):?>
		<div class="info_head">
			<label>请选择分类</label>
			<select	name="catid" id="select_catid" class="itemcate">
				<?php $options = JHtml::_('category.options','com_zmaxcdn',$config = array('filter.published' => array(1),'filter.access' =>array(1)));?>
				<?php echo JHtml::_('select.options',$options,'value','text',"",true);?>
			</select>
		</div>
		<?php else:?>
		<input type="hidden" name="catid" id="select_catid" value="<?php echo $this->config->catid;?>">	
		<?php endif;?>
		
		<!-- 这里也出现了extension了 -->
		<input type="hidden" name="extension" id="extension" value="<?php echo $this->config->extension;?>" />
	</div>
	
	
	<div class="qiniu-uploader">
		<div class="placeholder"  id="container">
			<table id="info-table" class=" table table-bordered "  style="display:none" >
				<thead>
					<td>文件名</td>
					<td>大小</td>
					<td>状态</td>
				</thead>
				<tbody id="fsUploadProgress">
				</tbody>
			</table>
			
			<div id="pickfiles" href="#">				
				<span class="webuploader-pick"><?php echo $this->config->upload_btn_text;?></span>
			</div>
			<?php echo $this->config->drag_text;?>
		</div>
	</div>
</div>

<script type="text/javascript">
	jQuery(function() {
		var uploader = Qiniu.uploader({
			runtimes: 'html5,flash,html4',
			browse_button: 'pickfiles',
			container: 'container',
			drop_element: 'container',
			max_file_size: FILE_SIZE_LIMIT+'M',
			extensions: FILE_TYPE_LIMIT,
			flash_swf_url: 'components/com_zmaxcdn/libs/7niu/Moxie.swf',
			dragdrop: true,
			chunk_size: '4mb',
			uptoken_url: 'index.php?option=com_zmaxcdn&task=upload.getUptoken',
			domain: YOU_QINIU_DOMAIN,
			auto_start: true,			
			init: {
				'FilesAdded': function(up, files) {							
					 jQuery('#info-table').show();             
					 plupload.each(files, function(file) {
						var progress = new FileProgress(file, 'fsUploadProgress');						
						progress.setStatus("等待...");
						progress.bindUploadCancel(up);
					});
				},
				'BeforeUpload': function(up, file) {
				},
				'UploadProgress': function(up, file) {
					var progress = new FileProgress(file, 'fsUploadProgress');
					var chunk_size = plupload.parseSize(this.getOption('chunk_size'));
					progress.setProgress(file.percent + "%", file.speed, chunk_size);
				},
				'UploadComplete': function() {
				},
				'FileUploaded': function(up, file, info) {
					var progress = new FileProgress(file, 'fsUploadProgress');
					//progress.setComplete(up, info);
				},
				'Error': function(up, err, errTip) {
					switch(err.code)
					{
						case plupload.FILE_SIZE_ERROR:
							alert("上传文件的大小超过了指定的大小!文件大小不超过"+FILE_SIZE_LIMIT+"M"); 
							break;
						default :
							alert(errtip);
							break;						
					}
				}
			}
		});

		uploader.bind('FileUploaded', function(up ,file ,info) 
		{
			try{
				var domain = up.getOption('domain');
				
				 var res = jQuery.parseJSON(info.response);
				 //alert(res.key);
				 if(res.key == undefined)
				 {
					res.key=file.name;
				 }
				 var cdnPath = domain + res.key;// 获取上传成功后的文件的Url			 
				 var name = file.name;
				 var type=file.type;
				 var size = file.size;
				 var catid = jQuery("#select_catid").val();
				 jQuery.ajax({
					type:'post',
					url:'index.php?option=com_zmaxcdn&task=<?php echo $this->escape($this->task);?>&uploader=cdn&function=<?php echo $this->escape($this->function);?>',
					data:{
						catid:catid,
						cdnPath:cdnPath,
						name:name,
						type:type,
						size:size,
					},
					cache:false,
					success:function(data){
						eval(data);
					},
					error:function()
					{					
						alert("添加失败，Ajax异常，请联系支持团队：Email:zhang19min88@163.com");
					}		
					
			});
			 }catch(e)
			 {
				alert(e.message);
			 }
		});
		jQuery('#container').on(
			'dragenter',
			function(e) {
				e.preventDefault();
				jQuery('#container').addClass('draging');
				e.stopPropagation();
			}
		).on('drop', function(e) {
			e.preventDefault();
			jQuery('#container').removeClass('draging');
			e.stopPropagation();
		}).on('dragleave', function(e) {
			e.preventDefault();
			jQuery('#container').removeClass('draging');
			e.stopPropagation();
		}).on('dragover', function(e) {
			e.preventDefault();
			jQuery('#container').addClass('draging');
			e.stopPropagation();
		});


	});

</script>	

	
	