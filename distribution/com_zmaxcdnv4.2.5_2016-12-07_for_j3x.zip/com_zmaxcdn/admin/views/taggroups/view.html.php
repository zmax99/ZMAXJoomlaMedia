<?php 
/**
 *	description:ZMAX媒体管理组件 标签组视图
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-07
 * @license GNU General Public License version 3, or later
 */

 
defined('_JEXEC') or die('Restricted access');


class zmaxcdnViewTaggroups extends JViewLegacy
{
     
     function display($tpl = null)	 
	 {
		$this->items = $this->get('Items');
		$this->pagination =$this->get('Pagination');
		$this->state =$this->get('State');
		$this->filterForm    = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');
		
		$this->listOrder = $this->state->get('list.ordering'); //需要排序的
		$this->listDir = $this->state->get('list.direction');//需要排序的方向
		
		if(count($errors = $this->get('Errors')))
		{
			JError::raiseError(500, implode('<br />',$errors));
			return false;
		}
		
		if ($this->getLayout() !== 'modal')
		{
			zmaxcdnHelper::addSubmenu('taggroups');
		}
		
		$this->addToolBar();
		$this->sidebar = JHtmlSidebar::render();
		
		parent::display($tpl);
		
	 }
	 
	 /**
	  * 设置工具栏
	  * 
	  * @access protected
	  */
	  protected function addToolBar()
	  {
		JToolBarHelper::title(JText::_("ZMAX媒体 - 标签组"),'filter');
		
		//JToolBarHelper::addNew该函数接受两个参数，一个是重载的任务 一个是文本
		JToolBarHelper::addNew('taggroup.add');
		JToolBarHelper::editList('taggroup.edit');
		//JToolBarHelper::publish('fieldgroups.publish',JTEXT::_("发布字段组") );
		//JToolBarHelper::unpublish('fieldgroups.unpublish' ,JTEXT::_("禁用字段组") );
		JToolBarHelper::deleteList('','taggroups.delete' );
		if (JFactory::getUser()->authorise('core.admin', 'com_zmaxcdn'))
		{
			JToolBarHelper::preferences('com_zmaxcdn');
		}
	  }
	  
}