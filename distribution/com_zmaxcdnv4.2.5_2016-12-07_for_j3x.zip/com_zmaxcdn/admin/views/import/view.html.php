<?php 
/**
 *	description:ZMAXCDN 资源视图文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2016-04-18
 *  @license GNU General Public License version 3, or later
 */ 
defined('_JEXEC') or die('Restricted access');

class zmaxcdnViewImport extends JViewLegacy
{
     public function display($tpl = null)	 
	 {
		$this->item = $this->get('Item');
		$this->form = $this->get('Form');
		JToolBarHelper::title(JText::_("ZMAX媒体管理 - 导入资源"),'lightning');
		JToolBarHelper::cancel('item.cancel','JTOOLBAR_CLOSE');
		JRequest::setVar('hidemainmenu' , true);
		$this->addToolBar();
		parent::display($tpl);
	 }
	 
	 protected function addToolBar()
	 {
		JToolBarHelper::save('import.import',"执行导入");		
	 }
}