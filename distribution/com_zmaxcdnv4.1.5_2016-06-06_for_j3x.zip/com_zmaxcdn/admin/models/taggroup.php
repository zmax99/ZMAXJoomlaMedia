<?php
/**
 *	description:ZMAX商城 字段组模型文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-07
 * @license GNU General Public License version 3, or later
 */
 
defined('_JEXEC') or die();

jimport('joomla.application.component.modeladmin');

class zmaxcdnModelTaggroup extends JModelAdmin
{
	/**
	 * Method to get the record form.
	 *
	 * @param   array      $data        Data for the form.
	 * @param   boolean    $loadData    True if the form is to load its own data (default case), false if not.
	 *
	 * @return  mixed  A JForm object on success, false on failure
	 * @since   1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$form = $this->loadForm('com_zmaxcdn.taggroup', 'taggroup', array('control' => 'jform', 'load_data' => $loadData));
		if (empty($form))
		{
			return false;
		}
		return $form;
	}
	
	public function loadFormData()
	{
		//Check the session for previously entered form data.
		$data = JFactory::getApplication()->getUserState('com_zmaxcdn.edit.taggroup.data',array());
		if (empty($data)) {
			$data = $this->getItem();
		}
		return $data;
	}
	

	/**
	 * Method to get a single record.
	 *
	 * @param   integer    The id of the primary key.
	 *
	 * @return  mixed  Object on success, false on failure.
	 */
	public function getItem($pk = null)
	{
		if ($item = parent::getItem($pk))
		{			
			$item->tags = json_decode($item->tags);
		}
		return $item;
	}
	
	
}


?>