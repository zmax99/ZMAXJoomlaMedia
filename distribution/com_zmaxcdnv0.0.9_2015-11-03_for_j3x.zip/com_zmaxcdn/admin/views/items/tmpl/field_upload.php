<?php

defined('_JEXEC') or die ('can not access this file!');
defined('_JEXEC') or die('Restricted access');
jimport('joomla.html.html.tabs');
?>
<h3>上传并插入<small>文件在上传完成后将自动被选中</small></h3>
<?php 
$options = array( 'onActive'=>'function(title ,description){
						description.setStyle("display","block");
						title.addClass("open").removeClass("closed");
						}'
					,
				   'onBackground'=>'function(title,description){
						description.setStyle("display" ,"none");
						title.addClass("closed").removeClass("open");
				   }'
				   ,
				   'startOffset'=>0
				   ,
				   'useCookie'=>true
				);
				
 echo JHtml::_('tabs.start' ,'tab_ground_id',$options);
 
	echo JHtml::_('tabs.panel' ,JText::_('上传到本地服务器'),'panel_1_id');
	echo $this->loadTemplate("upload_server");
 
 

 
	echo JHtml::_('tabs.panel' ,JText::_('上传到七牛CDN'),'panel_2_id');
	echo $this->loadTemplate("upload_remote");

 

 echo JHtml::_('tabs.end');
?>

					



