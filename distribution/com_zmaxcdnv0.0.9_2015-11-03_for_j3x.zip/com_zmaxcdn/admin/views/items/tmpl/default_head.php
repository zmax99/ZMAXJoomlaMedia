<?php
/**
 *	description:ZMAX商城 商品列表 布局头部
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2014-11-22
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');
?>

<tr>
	<th width="20px">
		<?php echo JHtml::_('grid.checkall'); ?>
	</th>
	<?php 
		$title = JHTML::_('searchtools.sort',JText::_("文件"),'name',$listDirn,$listOrder);
		$category = JHTML::_('searchtools.sort',JText::_("分类"),'category',$listDirn,$listOrder);
		$size = JHTML::_('searchtools.sort',JText::_("大小"),'size',$listDirn,$listOrder);
		$type = JHTML::_('searchtools.sort',JText::_("类型"),'type',$listDirn,$listOrder);
		$cdn_path = JHTML::_('searchtools.sort',JText::_("CDN地址"),'cdn_path',$listDirn,$listOrder);
		$date = JHTML::_('searchtools.sort',JText::_("上传时间"),'date',$listDirn,$listOrder);
		$description = JHTML::_('searchtools.sort',JText::_("备注"),'description',$listDirn,$listOrder);
	?>
	<th> <?php echo $title;?> </th>
	<td>预览</td>
	<th> <?php echo $category;?> </th>
	<th> <?php echo $size;?> </th>
	<th> <?php echo $type;?> </th>
	<th> <?php echo $cdn_path;?></th>
	<th> <?php echo $date;?></th>	
	<th> <?php echo $description;?></th>
</tr>
<?php
 $n = 0;
 foreach ($this->items as $item):
 $checked = JHTML::_('grid.id',$n,$item->id);
?>
 <tr >
	<td><?php echo $checked;?></td>
	<td><?php echo $item->title;?></td>
	<?//如果是图片类型?>
	<?php if($this->isImage($item->type)):?>
		<?php if($item->cdn_path):?>
		<td><img width="50px" height="50px" src="<?php echo $item->cdn_path;?>"></td>
		<?php else:?>
		<td><img width="50px" height="50px" src="<?php echo "components/com_zmaxcdn/".$item->local_path;?>"></td>
		<?php endif;?>
	<?php else:?>
		<td><img width="50px" height="50px" src="<?php echo "components/com_zmaxcdn/images/default.png";?>"></td>
	<?php endif; ?>
	<td><?php echo $item->category;?></td>
	<td><?php echo $item->size;?></td>
	<td><?php echo $item->type;?></td>
	<td><?php echo $item->cdn_path;?></td>
	<td><?php echo  JHTML::_('date' ,$item->date , JText::_('Y-m-d'));?></td>
	<td><?php  echo $item->description;?></td>
 </tr>
 <?php $n++;?>
<?php endforeach;?>
<tr>
	<td colspan="9">
		<?php  echo $this->pagination->getListFooter();?>
	</td>
</tr>
