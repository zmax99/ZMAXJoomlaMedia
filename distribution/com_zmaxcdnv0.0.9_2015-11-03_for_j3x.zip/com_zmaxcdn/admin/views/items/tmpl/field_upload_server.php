<?php 
//加载需要的css ,js
$doc = JFactory::getDocument();
$doc->addStyleSheet("components/com_zmaxcdn/libs/webuploader/webuploader.css");
$doc->addStyleSheet("components/com_zmaxcdn/libs/webuploader/wup.css");
$doc->addStyleSheet("components/com_zmaxcdn/libs/webuploader/style.css");
$doc->addScript("components/com_zmaxcdn/libs/webuploader/jquery-2.1.3.min.js");
$doc->addScript("components/com_zmaxcdn/libs/webuploader/webuploader.min.js");
$doc->addScript("components/com_zmaxcdn/libs/webuploader/wup_modal.js");
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');
$option = JRequest::getCmd('option');

?>
<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if (task == 'item.cancel' || document.formvalidator.isValid(document.id('item-form')))
		{
			Joomla.submitform(task, document.getElementById('item-form'));
		}
	}
</script>
<form action="<?php echo JRoute::_('index.php?option=com_zmaxcdn&layout=edit&id=');?>" method="post" name="adminForm" class="form-validate" id="item-form"  enctype="multipart/form-data">
<!--------------------------------------------->
	<div class="page-container">
		<div class="info_head">
			<label>请选择分类</label>
			<select	name="catid" id="select_catid" class="itemcate">
				<?php $options = JHtml::_('category.options','com_zmaxcdn',$config = array('filter.published' => array(1),'filter.access' =>array(1)));?>
				<?php echo JHtml::_('select.options',$options,'value','text',"",true);?>
			</select>
		</div>
		
		<div class="wu-example" id="uploader">
			<div class="queueList">
				<div class="placeholder" id="dndArea">
					<div id="filePicker" class="webuploader-container">
						<div class="webuploader-pick">点击选择图片</div>
					</div>
					<p>或将图片或者其他类型文件拖到这里</p>
				</div>
			</div>
		</div>
	<script type="text/javascript">
		// 添加全局站点信息
		var BASE_URL = '<?php echo JURI::root();?>components/com_zmaxcdn/libs/webuploader/';
		var DOMAIN_URL = '<?php echo JURI::root();?>';	
	</script>	
<!--------------------------------------------->
	<div>
		<input type="hidden" name="option" value="<?php echo $option;?>"/>
		<input type="hidden" name="task" value=""/>
		<input type="hidden" name="id" value="" />
		<?php echo JHtml::_('form.token');?>
	</div>
</form>
	
	