<?php
/**
 *	description:ZMAX CDN 资源控制器
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-24
 */
defined('_JEXEC') or die('');

jimport('joomla.application.component.controllerform');
	
class zmaxcdnControllerUpload extends JControllerForm
 {
	public function uploadItem()
	{
		$model = $this->getModel("uploader");
		$model->saveServer();		
		$app = JFactory::getApplication();
		$app->close();
	}
	

	public function uploadItemAndInsert()
	{
		
		
		$model = $this->getModel("uploader");
		$model->saveServer();	
		
		$session = JFactory::getSession();
		$data = $session->get("com_zmaxcdn.item.serverdata");
		$data = json_decode($data);
		
		$srcName=$data->name;
		$isImage = true;
		$url = zmaxcdnHelper::getSourecUrl($data);
		
		
		$js='
				var tag;
				tag=\'<img class="zmaximage" src="'.$url.'" alt="'.$srcName.'" />\';
				window.parent.jInsertEditorText(tag, "jform_articletext");
				window.parent.SqueezeBox.close();				
		';
		
		$message= $js;
		//JLog::add($message,JLOG::DEBUG ,'zmax');
		echo $message;
		
		$app = JFactory::getApplication();
		$app->close();
		
	}
	
	public function uploadCdn()
	{
		$model = $this->getModel("uploader");
		$model->saveCdn();		
		$app = JFactory::getApplication();
		$app->close();
	}
	
	public function uploadcdnAndInsert()
	{
		$model = $this->getModel("uploader");
		$model->saveCdn();
		
		$session = JFactory::getSession();
		$data = $session->get("com_zmaxcdn.item.remotedata");
		$data = json_decode($data);
		
		$srcName=$data->name;
		$isImage = true;
		$url = zmaxcdnHelper::getCDNUrl($data);
		
		
		$js='
				var tag;
				tag=\'<img class="zmaximage" src="'.$url.'" alt="'.$srcName.'" />\';
				window.parent.jInsertEditorText(tag, "jform_articletext");
				window.parent.SqueezeBox.close();				
		';
		
		$message= $js;
		//JLog::add($message,JLOG::DEBUG ,'zmax');
		echo $message;
		
		$app = JFactory::getApplication();
		$app->close();
	}
	
	public function getUptoken()
	{
		$app = JFactory::getApplication();
		$model = $this->getModel("uploader");
		$model->getUptoken();		
		$app->close();
	}
	
}	
	

?>