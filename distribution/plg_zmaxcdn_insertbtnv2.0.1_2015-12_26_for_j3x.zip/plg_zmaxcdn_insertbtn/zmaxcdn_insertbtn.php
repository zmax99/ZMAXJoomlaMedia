<?php

// no direct access
defined('_JEXEC') or die;

/**
 * Editor InsertPic buton
 *
 * @package		Joomla.Plugin
 * @subpackage	Editors-xtd.InsertPic
 * @since 1.5
 */
class plgButtonZmaxcdn_insertbtn extends JPlugin
{
	/**
	 * Constructor
	 *
	 * @access      protected
	 * @param       object  $subject The object to observe
	 * @param       array   $config  An array that holds the plugin configuration
	 * @since       1.5
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}

	/**
	 * Display the button
	 *
	 * @return array A two element array of (imageName, textToInsert)
	 */
	public function onDisplay($name, $asset, $author)
	{
		//echo $name;
		$app = JFactory::getApplication();
		$user = JFactory::getUser();
		$extension = $app->input->get('option');

		if ($asset == '')
		{
			$asset = $extension;
		}

		if (	$user->authorise('core.edit', $asset)
			||	$user->authorise('core.create', $asset)
			||	(count($user->getAuthorisedCategories($asset, 'core.create')) > 0)
			||	($user->authorise('core.edit.own', $asset) && $author == $user->id)
			||	(count($user->getAuthorisedCategories($extension, 'core.edit')) > 0)
			||	(count($user->getAuthorisedCategories($extension, 'core.edit.own')) > 0 && $author == $user->id))
		{
			
			$link = 'index.php?option=com_zmaxcdn&amp;view=items&layout=modal&amp;tmpl=component&amp;e_name=' . $name . '&amp;asset=' . $asset . '&amp;author=' . $author;
			JHtml::_('behavior.modal');
			$button = new JObject;
			$button->modal = true;
			$button->class = 'btn';
			$button->link = $link;
			$button->text = JText::_('ZMAX插入资源');
			$button->name = 'picture';
			$button->options = "{handler: 'iframe', size: {x: 800, y: 550}}";
			return $button;
		}
		else
		{
			return false;
		}	
	}
}
