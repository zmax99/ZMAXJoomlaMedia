<?php

// No direct access

defined ( '_JEXEC' ) or die ();

require_once(JPATH_ROOT."/administrator/components/com_zmaxcdn/helpers/zmaxcdn.php");
class plgZmaxcdnZmaxcdnAddon extends JPlugin {

	public function onBeforeShowItemTag($id ,&$tag)
	{
		$item =zmaxcdnHelper::getItemById($id);
		$url = zmaxcdnHelper::getSourecUrl($item);
		$extName = zmaxcdnHelper::getExt($item->name);
		$sourceInfo=$id."_".$item->name."——勿删播放视频代码";
		$tag="{zmaxloadplayer ".$sourceInfo."}";
	}

	public function onAfterInsertItem($id ,$item)
	{
		$resourceId = (string)$item->resourceid;
		//判断是否已经存在
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select("*")->from("#__zmaxarticle_map")->where("article_id=".$id)->where("extension='com_zmaxcdn'");
		$db->setQuery($query);
		$mapItem = $db->loadObject();
		if($mapItem)
		{
			$mapItem->attach_id = $resourceId;
			$db->updateObject("#__zmaxarticle_map" ,$mapItem);
		}
		else
		{
			$mapItem = new stdclass();
			$mapItem->article_id = $id ;
			$mapItem->attach_id = $resourceId ;
			$mapItem->user_id = JFactory::getUser()->id;
			$mapItem->extension = "com_zmaxcdn";
			$db->insertObject("#__zmaxarticle_map",$mapItem );
		}
		
	}
}
