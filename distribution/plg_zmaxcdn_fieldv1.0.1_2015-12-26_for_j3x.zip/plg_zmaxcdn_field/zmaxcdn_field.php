<?php
/**
 *	description:ZMAX媒体管理组件 媒体文件字段插件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-12-26
 */
 
 jimport('joomla.log.log');
 JLog::addLogger(array('text_file'=>'zmax.log.php') ,JLOG::ALL ,array('zmax' ,'jerror'));
 
class plgContentZmaxcdn_field extends JPlugin
{
	/**
	 *	constructor
	 *
	 * @access	 protected
	 * @param 	 object		$subject The object to observe
	 * @param 	 array 		$config	An array that holds the plugin configuration
	 * @since 	 1.5
	 */
	 public function __construct(& $subject ,$config)
	 {
		parent::__construct($subject,$config);
		$this->loadLanguage();
		
		//如果有自定义的字段，在此次添加即可
		JFormHelper::addFieldPath( 'components/com_zmaxcdn/models/fields');
	 }
	 public function onContentPrepareForm($form, $data)
	{
		if (!($form instanceof JForm))
		{
			$this->_subject->setError('JERROR_NOT_A_FORM');

			return false;
		}

		// Check we are manipulating a valid form.
		//$name = $form->getName();
		
		foreach ($form->getGroup('images') as $field)
		{
				if(strtolower($field->type)=="media")
				{
					
					$name = $this->getFieldRealName($field->name);
					$form->setFieldAttribute($name, 'type', 'zmaxfile' ,'images' );	
				}
				
		}		
		return true;
	}
	
	//得到字段的真实名字
	protected function getFieldRealName($fieldname)
	{
		$pos = strrpos($fieldname ,'[');
		$len = strlen($fieldname);
		if(!$pos) //理想情况下一定能够找到的
		{
			return $fieldname;	
		}
		
		return substr($fieldname ,$pos+1 ,$len-$pos-2);
	}

	
}
?>
