<?php
/**
 *	description:ZMAX媒体管理 ZMAXfile资源字段
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-12-25
 *  check date:2016-05-19
 *  checker :min.zhang
 */

defined('_JEXEC') or die('You Can Not Access This File!');
JHtml::_('jquery.framework');

$this->listOrder = $this->state->get('list.ordering');
$this->listDirn = $this->state->get('list.direction');
$this->function = JRequest::getCmd('function','selectItem');
$this->extension = JRequest::getCmd('extension');

$this->docType = JRequest::getCmd('doc_type');

$doc = JFactory::getDocument();
$doc->addStyleSheet("components/com_zmaxcdn/css/zmaxcdn.css");
$doc->addScript("components/com_zmaxcdn/js/zmaxcdn.js");
$doc->addScript(JUri::root()."/components/com_zmaxcdn/js/zmaxcdn_download.js");

//得到配置设置
$session = JFactory::getSession();
$config = $session->get("zmaxcdn.field.config");
$config = json_decode($config);
$this->config= $config;
$this->function = $session->get("zmaxcdn.field.function","selectItem");
$this->function = trim($this->function,'"');
$this->task = $session->get("zmaxcdn.field.task","upload.fieldUploadAndInsert");

$url = Juri::getInstance()->toString();

?>
<div id="modal">
	<form action="<?php echo $url;?>" method="post" name="adminForm" id="adminForm" class="forminline" enctype="multipart/form-data">
		<div id="j-main-container">	
			
			<?php if($this->config->show_file_list):?>
			<div id="itemlist_controller" class="btn btn-primary">显示或隐藏资源列表[字段类型]</div>
			<div id="itemlist">
				<?php if($this->config->show_search_tool):?>
				<?php	echo JLayoutHelper::render('joomla.searchtools.default', array('view' => $this));?>				 
				<?php endif;?>
				<?php if (empty($this->items)) : ?>
					<div class="alert alert-no-items">
						<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
					</div>
				<?php else : ?>		
					<hr class="hr-condensed" />
					<div class="items">
						<?php echo $this->loadTemplate('items');?>
					</div>
					<?php endif;?>
			</div>
			<hr class="hr-condensed"/>
			<?php endif;?>
			<div class="upload">
				<?php echo $this->loadTemplate('upload');?>
			</div>
		</div>
		<div>
				<input type="hidden" name="task" value=""/>
				<input type="hidden" name="boxchecked" value="0" />
				<?php echo JHtml::_('form.token');?>
		</div>	
	</form>
</div>