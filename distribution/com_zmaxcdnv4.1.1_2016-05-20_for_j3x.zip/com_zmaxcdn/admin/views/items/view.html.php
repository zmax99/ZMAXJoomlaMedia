<?php 
/**
 *	description:ZMAX CDN 资源列表视图
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2016-04-18
 *  @license GNU General Public License version 3, or later
 */
 
defined('_JEXEC') or die('Restricted access');

class zmaxcdnViewItems extends JViewLegacy
{
     function display($tpl = null)	 
	 {
		
		if ($this->getLayout() !== 'modal' && $this->getLayout() !== 'field')
		{
			zmaxcdnHelper::addSubmenu('items');
			$this->sidebar = JHtmlSidebar::render();
		}
		
		$this->items = $this->get('Items');
		$this->form = $this->get('Form');
		$this->pagination =$this->get('Pagination');
		$this->state =$this->get('State');
		$this->filterForm    = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');
		
		$this->listOrder = $this->state->get('list.ordering'); //需要排序的
		$this->listDir = $this->state->get('list.direction');//需要排序的方向
		
		
		if(count($errors = $this->get('Errors')))
		{
			JError::raiseError(500, implode('<br />',$errors));
			return false;
		}
		
		$this->addToolBar();
		parent::display($tpl);
	 }
	 
	  protected function addToolBar()
	  {
		JToolBarHelper::title(JText::_("ZMAX媒体管理 - 资源列表"));				
		JToolBarHelper::addNew('item.add');
		JToolBarHelper::editList('item.edit');
		JToolBarHelper::deleteList("你确定要删除这个资源吗？在删除记录的同时也会删除存储在服务器上的文件",'items.delete');
		JToolBarHelper::publish('items.publish');
		JToolBarHelper::unpublish('items.unpublish'  );
		
		if (JFactory::getUser()->authorise('core.admin', 'com_zmaxcdn'))
		{
			JToolBarHelper::preferences('com_zmaxcdn');
		}
		
		//添加一个批处理按钮
		JHtml::_('bootstrap.modal', 'collapseModal');
		$title = JText::_('JTOOLBAR_BATCH');
		$layout = new JLayoutFile('joomla.toolbar.batch');
		$dhtml = $layout->render(array('title' => $title));
		$bar = JToolBar::getInstance('toolbar');
		$bar->appendButton('Custom', $dhtml, 'batch');
	  }
	  
}