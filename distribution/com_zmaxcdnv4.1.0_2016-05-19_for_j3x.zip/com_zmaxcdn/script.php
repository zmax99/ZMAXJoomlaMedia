<?php
/**
 *	description:ZMAX媒体管理组件 安装脚本
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2014-11-22
 * @license GNU General Public License version 3, or later
 *  check date:2016-05-20
 *  checker :min.zhang
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');	
if(!defined('DS')) define('DS', DIRECTORY_SEPARATOR);

/**
 *	Script file of captcha component
 **/
 class com_zmaxcdnInstallerScript
 {
	/**
	 *	method to install the component
	 *  @return void
	 */
	 function install($parent)
	 {
		// $parent is the class calling this method
		$this->installExtension();
	 }
	 
	 /**
	  *	method to uninstall the component
	  *	@return void
	  **/
	  function uninstall($parent)
	  {
		// $parent is the calss calling this method
	  }
	  
	  /**
	   *	method to update the component
	   *	@return void
	   **/
	  function update($parent)
	  {
		$this->installExtension();
		// $parent is the class calling this method
		//echo "<p>".JText::sprintf('COM_CAPTCHA_UPDATE_TEXT' ,$parent->get('manifest')->version).'</p>';

	  }
	  
	  /**
	   *	method to runbefore on install/update/unistall method
	   *	@return void
	   **/
	  function preflight($type ,$parent)
	  {
		// $parent is the class calling this method
		// $type is the type change (install ,update or discover_install)
		
	  }
	  
	  /**
	   *	method to run after on install/update/uninstall method
	   *	@return void
	   */
	   function postflight($type ,$parent)
	   {
			//$parent is the class calling this method
			//$type is the type of change (install ,update or discover_install)
			//$this->hideAdminMenu();
			
	   }
	   
	   protected function installExtension()
	   {
			jimport('joomla.installer.helper');
			$installer = new JInstaller();

			$pk_path = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_zmaxcdn'.DS.'extensions';
			
			
			$files = array();
			if(is_dir($pk_path))
			{
				if($hDir = opendir($pk_path))
				{
					while( ($file = readdir($hDir) ) !== false)
					{
						//if($file !="." && $file !=".." && is_file($file))
						if($file !="." && $file !="..")
						{
							if(is_file($pk_path.DS.$file))
							{
									 $ext = JFile::getExt($file);
									 if($ext=="zip")
									 {
										$files[] = $file;
									}
							}
						}
					}
				}
			}
			else
			{
				$app = JFactory::getApplication();
				$app->enqueueMessage("Install Error ,Please contact the author! Email:zhang19min88@163.com");
			}
			
			
			if(count($files) != 0)
			{
				foreach($files as $pk_file)
				{
					$msgText=array();
					$package = JInstallerHelper::unpack($pk_path.DS.$pk_file);	
					if($installer->install( $package['dir']))
					{
						$msgText[]='<div class="alert alert-success">';
						$msgText[]='<h4 class="alert-heading">消息</h4>';
						$msgText[]='<p>';
						$msgText[] = $pk_file." Install OK!";
						$msgText[]="</p>";
						$msgText[]="</div>";
					}
					else
					{
						$msgText[]='<div class="alert ">';
						$msgText[]='<h4 class="alert-heading">警告</h4>';
						$msgText[]='<p>';
						$msgText[] = $pk_file." Install Failed!";
						$msgText[]="</p>";
						$msgText[]="</div>";
					}
					echo implode("\r\n" ,$msgText);
					
					JInstallerHelper::cleanupInstall($pk_path.DS.$pk_file ,$package['dir']);
					JFolder::delete($package["extractdir"]);
				}
			}
			//这里稍后在修改了
			//JFolder::delete($pk_path);
			$this->enablePlugin();
			$this->installDemo();
			
	   }
	   
	   protected function hideAdminMenu()
	   {
			// Do Nothing
	   }
	   
	   protected function installDemo()
	   {
		    // Create categories for our component
			$basePath = JPATH_ADMINISTRATOR . '/components/com_categories';
			require_once $basePath . '/models/category.php';
			$config = array( 'table_path' => $basePath . '/tables');
			$catmodel = new CategoriesModelCategory( $config);
			
			//创建默认分类
			$catData = array( 'id' => 0, 'parent_id' => 1, 'level' => 1, 'path' => 'zmaxcdn-default-category', 'extension' => 'com_zmaxcdn'
			, 'title' => '默认分类', 'alias' => 'zmaxcdn-default-category', 'description' => '<p>ZMAX媒体组件默认资源分类</p>', 'published' => 1, 'language' => '*');
		
			$status = $catmodel->save( $catData);			
			
			if(!$status) 
			{
				JError::raiseWarning(500, JText::_('ZMAX媒体组件创建默认分类失败!'));
			}		   
	   }
	   
	   protected function enablePlugin()
	   {
			$db = JFactory::getDBO();
			$sql = "UPDATE #__extensions SET enabled = '1' WHERE type = 'plugin' AND name ='plg_editors-xtd_zmaxcdn_insertbtn'";
			$db->setQuery($sql);
			$db->query();
	   }
 }
?>