<?php 
//加载需要的css ,js
$doc = JFactory::getDocument();
$doc->addStyleSheet("components/com_zmaxcdn/libs/7niu/main.css");
$doc->addStyleSheet("components/com_zmaxcdn/libs/7niu/highlight.css");
$doc->addScript("components/com_zmaxcdn/libs/7niu/jquery-1.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/bootstrap.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/plupload.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/zh_CN.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/ui.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/qiniu.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/highlight.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/main_modal.js");

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');
$option = JRequest::getCmd('option');

$params = JComponentHelper::getParams("com_zmaxcdn");		
$yourQiNiuDomain = $params->get("domain");
$yourQiNiuDomain = "http://".$yourQiNiuDomain."/";

?>

	<div >
		<div class="wrapper">
		<div class="info_head">
			<label>请选择分类</label>
			<select	name="catid" id="select_catid" class="itemcate">
				<?php $options = JHtml::_('category.options','com_zmaxcdn',$config = array('filter.published' => array(1),'filter.access' =>array(1)));?>
				<?php echo JHtml::_('select.options',$options,'value','text',"",true);?>
			</select>
		</div>
		
		
		<div class=" wu-example">
			<div class="placeholder" style="position: relative;" id="container">
				<a style="position: relative; z-index: 1;" id="pickfiles" href="#">				
					<span class="webuploader-pick">选择文件</span>
					<p>或将图片或者其他类型文件拖到这里</p>
				</a>
			</div>
		</div>
		
	</div>

	<script type="text/javascript">
		// 添加全局站点信息
		var YOU_QINIU_DOMAIN = '<?php echo $yourQiNiuDomain;?>';	
	</script>	

	
	