<?php
defined('_JEXEC') or die ('can not access this file!');
jimport('joomla.html.html.tabs');
?>
<h3>上传并插入<small>文件在上传完成后将自动插入到文章中</small></h3>
<?php 			
 echo JHtml::_('tabs.start' ,'tab_ground_id');
 
	echo JHtml::_('tabs.panel' ,JText::_('上传到本地服务器'),'panel_1_id');
	echo $this->loadTemplate("upload_server");
 
	echo JHtml::_('tabs.panel' ,JText::_('上传到七牛CDN'),'panel_2_id');
	echo $this->loadTemplate("upload_remote");

 echo JHtml::_('tabs.end');
?>


