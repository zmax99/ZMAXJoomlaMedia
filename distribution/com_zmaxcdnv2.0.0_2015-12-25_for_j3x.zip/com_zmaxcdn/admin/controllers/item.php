<?php
/**
 *	description:ZMAX CDN 资源控制器
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-24
 */
defined('_JEXEC') or die('');

jimport('joomla.application.component.controllerform');
	
class zmaxcdnControllerItem extends JControllerForm
 {
 
	public function addRemote()
	{
		$this->setRedirect("index.php?option=com_zmaxcdn&view=addremote");
	}
	public function addServer()
	{
		$this->setRedirect("index.php?option=com_zmaxcdn&view=addserver");
	}
	
	public  function editsave()
	{
		$jinput = JFactory::getApplication()->input;
		$data = $jinput->get('jform','','array');
		$id = $data["id"];
		
		$model = $this->getModel();
		if($model->saveEdit($data))
		{
			$message=JText::_("编辑资源成功");
			$type="message";
		}
		else
		{
			$message=JText::_("编辑资源失败!");
			$type="error";
		}
		
		$this->setRedirect("index.php?option=com_zmaxcdn&view=item&layout=edit&id=".$id,$message ,$type);
	}
	
	
	public function save($key = NULL, $urlVar = NULL)
	{
		$jinput = JFactory::getApplication()->input;
		$data = $jinput->get('jform','','array');
		
		$file = $jinput->files->get('jform');
		$data = array_merge($data, $file);		
		
		//print_r($data);
		
		
		$model = $this->getModel();
		if($model->save($data))
		{
			$message=JText::_("添加资源成功");
			$type="message";
		}
		else
		{
			$message=JText::_("添加资源失败!");
			$type="error";
		}
		
		$this->setRedirect("index.php?option=com_zmaxcdn&view=items",$message ,$type);
		
	}
	
	public function uploadInsert()
	{
		$jinput = JFactory::getApplication()->input;
		$data = $jinput->get('jform','','array');
		
		$file = $jinput->files->get('jform');
		$data = array_merge($data, $file);		
		
		
		$model = $this->getModel();
		if(!$model->save($data))
		{
			return false;
		}
		
		
		$session = JFactory::getSession();
		$data = $session->get("com_zmaxcdn.item.data");
		$data = json_decode($data);
		
		
		$params = JComponentHelper::getParams("com_zmaxcdn");
		$domain = $params->get("domain");
		
		$path = "components/com_zmaxcdn/".$data->local_path;
		$url = "administrator/".$path;
		if($data->cdn_path)
		{
			$url = "http://".$domain."/".$data->cdn_path;
		}
		$srcName=$data->name;
		$isImage = true;
		
		
		$js='
			<script>
				var tag;
				tag=\'<img class="zmax_upload_image" src="'.$url.'" alt="'.$srcName.'" />\';
				window.parent.jInsertEditorText(tag, "jform_articletext");
				window.parent.SqueezeBox.close();				
			</script>
		';
		
		$message= $js;
		//JLog::add($message,JLOG::DEBUG ,'zmax');
		echo $message;
		//$this->setRedirect($link,$message);
		
	
	}
	
	/**
	 * Method to run batch operations.
	 *
	 * @param   object  $model  The model.
	 *
	 * @return  boolean   True if successful, false otherwise and internal error is set.
	 *
	 * @since   1.6
	 */
	public function batch($model = null)
	{
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

		// Set the model
		$model = $this->getModel('item', '', array());

		// Preset the redirect
		$this->setRedirect(JRoute::_('index.php?option=com_zmaxcdn&view=items' . $this->getRedirectToListAppend(), false));

		return parent::batch($model);
	}
 }	
	

?>