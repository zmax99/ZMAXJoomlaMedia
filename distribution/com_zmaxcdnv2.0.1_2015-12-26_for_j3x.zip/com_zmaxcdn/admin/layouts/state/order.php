<?php 
defined('JPATH_BASE') or die;
?>
<?php if($displayData=="待处理"):?>
<span style="color:blue"><?php echo $displayData;?></span>
<?php elseif($displayData == "正常"):?>
<span style="color:green"><?php echo $displayData;?></span>
<?php else:?>
<span style="color:red"><?php echo $displayData;?></span>
<?php endif;?>
