<?php
/**
 *	description:ZMAXCDN 项目列表布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-11-08
 */
defined('_JEXEC') or die('You Can Not Access This File!');
jimport('joomla.html.html.tabs');
?>
<h3>上传并插入<small>文件在上传完成后将自动被选中</small></h3>
<?php 
				
	echo JHtml::_('tabs.start' ,'tab_ground_id');
 
	echo JHtml::_('tabs.panel' ,JText::_('上传到本地服务器'),'panel_1_id');
	echo $this->loadTemplate("upload_server");
 
	echo JHtml::_('tabs.panel' ,JText::_('上传到七牛CDN'),'panel_2_id');
		echo $this->loadTemplate("upload_remote");
		
	echo JHtml::_('tabs.end');
?>

					



