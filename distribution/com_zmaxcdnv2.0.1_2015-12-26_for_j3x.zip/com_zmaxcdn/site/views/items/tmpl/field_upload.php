<?php
/**
 *	description:ZMAXCDN 项目列表布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-11-08
 */
defined('_JEXEC') or die('You Can Not Access This File!');
jimport('joomla.html.html.tabs');
?>
<h3>上传并插入<small>文件在上传完成后将自动被选中</small></h3>
<?php 
$options = array( 'onActive'=>'function(title ,description){
						description.setStyle("display","block");
						title.addClass("open").removeClass("closed");
						}'
					,
				   'onBackground'=>'function(title,description){
						description.setStyle("display" ,"none");
						title.addClass("closed").removeClass("open");
				   }'
				   ,
				   'startOffset'=>0
				   ,
				   'useCookie'=>true
				);
				
 echo JHtml::_('tabs.start' ,'tab_ground_id',$options);
 
	echo JHtml::_('tabs.panel' ,JText::_('上传到本地服务器'),'panel_1_id');
	echo $this->loadTemplate("upload_server");
 
 

 
	echo JHtml::_('tabs.panel' ,JText::_('上传到七牛CDN'),'panel_2_id');
	//echo $this->loadTemplate("upload_remote");
	/**
	 *
	 *	由于存在bug，所以将七牛CDN重新定位为辅助功能 目前先禁止 后续版本中加上
	 *
	 *  TODO;
	 *
	 */
	?>
	<div class="alert alert-info">
		<p>上传文件到七牛CDN由于存在不稳定的因素，程序目前禁用了此功能。我们会尽快发布新的版本来完善！</p>
	</div>	

 <?php
	echo JHtml::_('tabs.end');
?>

					



