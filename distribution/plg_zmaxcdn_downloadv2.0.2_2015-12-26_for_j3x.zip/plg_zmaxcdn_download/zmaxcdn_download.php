<?php
jimport('joomla.log.log');
if(!defined('DS')){define('DS',DIRECTORY_SEPARATOR);}
	


class plgSystemZmaxcdn_download extends JPlugin
{
    /**
     * @return void  
     */
     public function onBeforeRender()
     {
		$app = JFactory::getApplication();
		if($app->isAdmin())
		{
			return true;
		}
      	$doc = JFactory::getDocument();
		$js ='var SITEBASE ="'.JUri::root().'"';
		$doc->addScriptDeclaration($js);
		$doc->addScript("plugins/system/zmaxcdn_download/zmaxcdn_download.js");
		
		return true;
     }

     

}
?>
