<?php 
/**
 *	description:ZMAXCDN 资源视图文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2016-04-18
 *  @license GNU General Public License version 3, or later
 */ 
defined('_JEXEC') or die('Restricted access');

class zmaxcdnViewItem extends JViewLegacy
{
     public function display($tpl = null)	 
	 {
		$item = $this->get('Item');
		$form = $this->get('Form');

		$this->item = $item;
		$this->form = $form;
		
		$isNew = ($item->id < 1);
		if($isNew)
		{			
			JToolBarHelper::title(JText::_("ZMAX媒体管理 - 添加资源"));
		}
		else
		{
			JToolBarHelper::title(JText::_("ZMAX媒体管理 - 编辑资源"));
		}
		JToolBarHelper::cancel('item.cancel',$isNew ? 'JTOOLBAR_CANCEL':'JTOOLBAR_CLOSE');
		
		JRequest::setVar('hidemainmenu' , true);
		$this->addToolBar();
		parent::display($tpl);
	 }
	 
	 protected function addToolBar()
	 {
		JToolBarHelper::save('item.save');
		JToolBarHelper::apply('item.apply');
	 }
}