<?php
/**
 *	description:ZMAX媒体管理 上传配置控制器
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2014-11-22
 *  @license GNU General Public License version 3, or later
 *  check date:2016-05-19
 *  checker :min.zhang
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controlleradmin');
class zmaxcdnControllerConfigs extends JControllerAdmin
 {
	 public function getModel($name = 'config' ,$prefix = 'zmaxcdnModel' ,$config = array())
	 {
		return parent::getModel($name , $prefix ,$config);
	 }
 }	
	

?>