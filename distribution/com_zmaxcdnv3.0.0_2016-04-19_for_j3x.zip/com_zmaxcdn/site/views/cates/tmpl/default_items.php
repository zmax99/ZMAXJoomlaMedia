<?php
/**
 *	description:ZMAX媒体管理组件 项目列表布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-11-03
 */
defined('_JEXEC') or die('You Can Not Access This File!');
$i = 0;
?>
<div class="zmaxui">
	<div class="zmax-row">
		<?php foreach($this->items as $cate):?>	
			<?php if($cate && count($cate)):?>
			  <?php $i++;?>
			  <div class="zmax-col-md-6">
				<div class="zmax-down-cate">
					<h3 class="down-cate"><?php echo $cate[0]->category;?></h3>
					
					<div class="zmax-row">
						<div class="items-info">
						<?php foreach($cate as $item):?>
						
							<div class="zmax-col-md-6"><div class="item-title"><?php echo $item->title;?></div></div>
							<div class="zmax-col-md-3"><?php echo zmaxcdnHelper::formatDocType($item->doc_type);?></div>
							<div class="zmax-col-md-3"><a href="#" class="zmaxpackage" data-id="<?php echo $item->id;?>" ><i class="fa fa-download"></i>下载</a></div>
						<?php endforeach;?>
						<div class="zmax-col-md-12">
							<div class="zmax-down-cate-readmore zmax-pull-right">
								<a class="down-more"href="index.php?option=com_zmaxcdn&view=items&id=<?php echo $item->catid;?>">更多</a>
							</div>
						</div>
						</div>
					</div>
				</div>
			</div>	
			<?php if($i%2==0):?>
				</div><div class="zmax-row">
			<?php endif;?>
			<?php endif;?>
		<?php endforeach;?>
	</div>
</div>
