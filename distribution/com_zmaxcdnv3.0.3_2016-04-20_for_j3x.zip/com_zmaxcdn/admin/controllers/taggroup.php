<?php
/**
 *	description:ZMAX媒体管理 自定义字段组控制器
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-07
 * @license GNU General Public License version 3, or later
 */
defined('_JEXEC') or die('');

jimport('joomla.application.component.controllerform');
	
class zmaxcdnControllerTaggroup extends JControllerForm
 {	
	function save($key = null ,$urlVar = null)
	{
		$jinput = JFactory::getApplication()->input;
		
		$data = $jinput->get('jform','','array');
		if (isset($data["tags"]) && is_array($data["tags"]))
		{
				$registry = new JRegistry;
				$registry->loadArray($data["tags"]);
				$data["tags"] = (string) $registry;
		}
		return parent::save();
		/*$model = $this->getModel("fieldgroup");
		$item = $model->checkFieldGroupExist($data["cateid"] ,$data["id"]);
		if($item)
		{
			$type="Error";
			$message="保存失败!<br/>该分类已经绑定了如下的字段组:".$item->title."(".$item->description.").<br/>如果你需要重新绑定，请前往编辑该字段组";
			$this->setRedirect("index.php?option=com_zmaxcdn&view=fieldgroups",$message ,$type);	
		}
		else 
		{
			return parent::save();
		}
		*/
	}
 }	
	

?>