<?php
/**
 *	description:ZMAX媒体管理 自定义字段组控制器
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-07
 * @license GNU General Public License version 3, or later
 */
defined('_JEXEC') or die('');

jimport('joomla.application.component.controllerform');
	
class zmaxcdnControllerConfig extends JControllerForm
 {	
	public function save($key = NULL, $urlVar = NULL)
	{
		$app = JFactory::getApplication();
		$data = $app->input->get("jform","","ARRAY");
		//$data = JRequest::get("POST");
		
		echo "<pre>";
			print_r($data);
		echo "</pre>";
		return parent::save();
	}
	
 }	
	

?>