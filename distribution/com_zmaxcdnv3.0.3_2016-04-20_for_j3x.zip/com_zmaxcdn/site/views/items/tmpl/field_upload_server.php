<?php
 /**
  *	 description:ZMAXCDN 项目列表布局文件
  *  author：min.zhang
  *  Email:zhang19min88@163.com
  *	 Url:http://www.zmax99.com
  *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
  *  date:2015-11-08
  */
 defined('_JEXEC') or die('You Can Not Access This File!');
 //webUpload CSS + JS
$doc = JFactory::getDocument();
$doc->addStyleSheet(JUri::root()."/administrator/components/com_zmaxcdn/libs/webuploader/wup.css");
$doc->addScript(JUri::root()."/administrator/components/com_zmaxcdn/libs/webuploader/webuploader.min.js");
$doc->addScript(Juri::root()."/administrator/components/com_zmaxcdn/libs/webuploader/wup.js");

 ?>

<div class="page-container">
	<?php if(!$this->config->catid):?>
	<div class="info_head">
		<label>请选择分类</label>
		<select	name="catid" id="select_catid" class="itemcate">
			<?php $options = JHtml::_('category.options','com_zmaxcdn',$config = array('filter.published' => array(1),'filter.access' =>array(1)));?>
			<?php echo JHtml::_('select.options',$options,'value','text',"",true);?>
		</select>
	</div>
	<?php else:?>
	<input type="hidden" name="catid" id="select_catid" value="<?php echo $this->config->catid;?>">	
	<?php endif;?>
	<input type="hidden" name="extension" id="extension" value="<?php echo $this->config->extension;?>" />
	
	<div  id="uploader">
		<div class="queueList">
			<div class="placeholder" id="dndArea">
				<div id="filePicker" class="webuploader-container">
					<div class="webuploader-pick"><?php echo $this->config->upload_btn_text;?></div>
				</div>
				<h4><b><?php echo $this->config->drag_text;?></b></h4>
			</div>
		</div>
	</div>
	
<!--  webupload 的配置文件-->
<script type="text/javascript">
// 添加全局站点信息
var BASE_URL = '<?php echo JURI::root();?>components/com_zmaxcdn/libs/webuploader/';
var DOMAIN_URL = '<?php echo JURI::root();?>';	
var SERVER_URL ='index.php?option=com_zmaxcdn&task=upload.fieldUploadAndInsert&uploader=server&function=<?php echo $this->escape($this->function);?>';
var UPLOADER_VIEW = 'field';
var FILE_SIZE_LIMIT = '<?php echo $this->config->max_size;?>';
var FILE_TYPE_LIMIT = '<?php echo $this->config->file_type;?>';
var UPLOAD_BTN_TEXT = '<?php echo $this->config->upload_btn_text;?>';
</script>

	

	
	