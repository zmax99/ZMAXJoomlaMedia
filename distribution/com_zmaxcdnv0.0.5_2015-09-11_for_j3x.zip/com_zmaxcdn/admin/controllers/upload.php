<?php
/**
 *	description:ZMAX CDN 资源控制器
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-24
 */
defined('_JEXEC') or die('');

jimport('joomla.application.component.controllerform');
	
class zmaxcdnControllerUpload extends JControllerForm
 {
	public function uploadItem()
	{
		$model = $this->getModel("uploader");
		$model->uploadItem();		
		$app = JFactory::getApplication();
		$app->close();
	}
	
	public function uploadCdn()
	{
		$model = $this->getModel("uploader");
		$model->saveCdn();		
	}
	
	public function getUptoken()
	{
		$app = JFactory::getApplication();
		$model = $this->getModel("uploader");
		$model->getUptoken();		
		$app->close();
	}
	
}	
	

?>