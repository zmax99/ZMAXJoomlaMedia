<?php
/**
 *	description:ZMAX资源模型文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-09-06
 */

defined('_JEXEC') or die();
jimport('joomla.application.component.modeladmin');
use Qiniu\Auth;
use Qiniu\Storage\UploadManager;
use Qiniu\Storage\BucketManager;

require_once(JPATH_COMPONENT.DS."libs".DS."7niu".DS."vendor".DS."autoload.php");
require_once(JPATH_COMPONENT.DS."libs".DS."webuploader".DS."webserver.php");

class zmaxcdnModelUploader extends JModelAdmin
{
	public $_data = array();

	public function getForm( $data = array() , $loadData = true)
	{
		//Get the form
		$form = $this->loadForm('com_zmaxcdn.item' ,'item' ,array('control' =>' jform' ,'load_data' => $loadData ));
		if(!$form)
		{
			return false;
		}
		
		return $form;
	}
	
	public function loadFormData()
	{
		//Load form data
		$data = $this->getItem();
		return $data;
	}
	
	public function uploadItem()
	{
		$this->_uploadItem();
		// Return Success JSON-RPC response
		//die('{"jsonrpc" : "2.0", "result" : null, "id" : "id"}');
	}
	
	public function saveCdn()
	{
		$this->data["uid"]=JFactory::getUser()->id;
		$this->data["create_date"] = $this->getPostDate();
		$this->data["catid"] = "18";
		$this->data["filename"]="";
		$this->data["local_path"]="";
		$this->data["size"] = JRequest::getVar("size");
		$this->data["type"] = JRequest::getVar("type");
		$this->data["name"] = JRequest::getVar("name");
		$this->data["cdn_path"] = JRequest::getVar("cdnPath");
		
		//存储数据
		$table = $this->getTable("item");
		
		if(!$table->bind($this->data))
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		
		if(!$table->check())
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if(!$table->store())
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
	}
	
	public function _uploadItem()
	{
		$webServer = new zmaxcdnWebserver();
		$webServer->enableLog();
		$webServer->uploadFile();
		$fileInfo = $webServer->getFileInfo();
		if($fileInfo["done"])
		{
			$this->data = $fileInfo;
			$this->_storeItem();
		}
		
	}
	
	
	protected function _storeItem()
	{	
		$this->data["uid"]=JFactory::getUser()->id;
		$this->data["create_date"] = $this->getPostDate();
		$this->data["catid"] = "18";
		$this->data["local_path"]="/source/".$this->data["filename"];
		
		//存储数据
		$table = $this->getTable("item");
		
		if(!$table->bind($this->data))
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		
		if(!$table->check())
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		if(!$table->store())
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		
	}
	
	
	
	//得到文件的扩展名
	public function getExt($fileName)
	{
		return strrchr($fileName,'.');
	}
	
	//获得文件唯一的名字
	public function makeName($type ,$catid)	
	{		
		$year = date("Y");
		$month = date("m");
		$day = date("d");
		$hour = date("H");
		$min = date("i");
		$sec = date("s");
		$filename = $catid."_".$year.$month.$day.$hour.$min.$sec.$type;
		return $filename;
	}
	//得到提交订单的时间
    public function getPostDate()
	{
		date_default_timezone_set('PRC');
		$date= date("Y-m-d H:i:s");
		$now = JDate::getInstance($date);
		return $now->toSql();
	}
	
	
	public function uploadQiniu($file)
	{
		return "";
		/*
		$file = 'D:\wamp\www\test\source\anzhuang_joomla01.png';
		$file = 'D:\wamp\www\test\source\webUploderDemo.15.08.14.zip';
		$file = 'D:\wamp\www\test\source\zmaxtest.mp4';

		$cdn_path ="";
		$params = JComponentHelper::getParams("com_zmaxcdn");
		$enableQiniu = $params->get("enable_qiniu",'0');
		
		if($enableQiniu)
		{

			
			// 设置信息
			$APP_ACCESS_KEY = $params->get("accessKey");
			$APP_SECRET_KEY = $params->get("secretKey");
			$bucket = $params->get("bucket");
			
			
			
			//得到一个认证对象
			$auth = new Auth($APP_ACCESS_KEY, $APP_SECRET_KEY);
			$token = $auth->uploadToken($bucket);
			$uploadManager = new UploadManager();
			
			//执行上传 (多次上传同一个文件不会有任何的作用)
			list($ret, $err) = $uploadManager->putFile($token, null, $file);
			if ($err != null) 
			{
				//$this->_message = "上传失败。错误消息：".$err->message();
				return false;
			}
			$cdn_path= $ret["key"] ;		
		}
		
		return $cdn_path;	
		*/
	}
	
	public function getUptoken()
	{
		$params = JComponentHelper::getParams("com_zmaxcdn");
		
		// 设置信息
		$APP_ACCESS_KEY = $params->get("accessKey");
		$APP_SECRET_KEY = $params->get("secretKey");
		$bucket = $params->get("bucket");
		
		//得到一个认证对象
		$auth = new Auth($APP_ACCESS_KEY, $APP_SECRET_KEY);
		$token = $auth->uploadToken($bucket);
		
		$tk = array('uptoken'=>$token);
		$tk = json_encode($tk);
		echo $tk;
	}
	
	
}


?>