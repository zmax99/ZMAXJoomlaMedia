<?php
/**
 *	description:ZMAX商城 项目列表布局文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-05-09
 */
defined('_JEXEC') or die('You Can Not Access This File!');

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');
$option = JRequest::getCmd('option');
$com = JRequest::getVar("com");
$view = JRequest::getCmd('view');
?>

<form action="<?php echo JRoute::_('index.php?option=com_zmaxcdn&view=items');?>" method="post" name="adminForm" id="adminForm" class="forminline" enctype="multipart/form-data">
	<div id="j-main-container">	
		<?php
			// Search tools bar
			echo JLayoutHelper::render('joomla.searchtools.default', array('view' => $this));
		?>
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-no-items">
				<?php echo JText::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
			</div>
		<?php else : ?>
			<hr class="hr-condensed">
			<div class="items">
				<?php if($com=="guru"):?>
				<?php echo $this->loadTemplate('items_guru');?>
				<?php else:?>
				<?php echo $this->loadTemplate('items');?>
				<?php endif;?>
			</div>
			<hr class="hr-condensed">
			<div class="upload">
				<?php echo $this->loadTemplate('upload');?>
			</div>
		<?php endif;?>
	
	</div>
	<div>
			<input type="hidden" name="task" value=""/>
			<input type="hidden" name="option" value="<?php echo $option;?>"/>
			<input type="hidden" name="view" value="<?php echo $view;?>"/>
			<input type="hidden" name="boxchecked" value="0" />
			<?php echo JHtml::_('form.token');?>
	</div>	
</form>