<?php

defined('_JEXEC') or die ('can not access this file!');

$option = JRequest::getCmd('option');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
$function	= JRequest::getCmd('function', 'InsertImage');
?>
<div >
	<h3><?php echo JText::_('上传并插入');?></h3>
	<div class="row-fluid">
		<div class="span12">
			<fieldset class="adminform">
				<div class="span6">
				<?php 
					$fields = $this->form->getFieldset("itemdetail");
					$nCount = count($fields);
					$lineNum = (int)($nCount/2);
					$lineNum=$lineNum+1;
					$i = 0;
					foreach($fields as $field)
					{
						$i++;
						echo $field->renderField();
						if($i == $lineNum )
						{
							echo '</div><div class="span6">';	
						}
					}
				?>
				</div>
					
			</fieldset>
		</div>
	</div>
	<div ><a href="#" class="btn btn-info" onclick="Joomla.submitbutton('item.uploadInsert');"><?php echo JText::_('上传并插入');?></a></div>		
</div>
