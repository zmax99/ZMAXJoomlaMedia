<?php 
//加载需要的css ,js
$doc = JFactory::getDocument();
$doc->addStyleSheet("components/com_zmaxcdn/libs/7niu/main.css");
$doc->addStyleSheet("components/com_zmaxcdn/libs/7niu/highlight.css");
$doc->addScript("components/com_zmaxcdn/libs/7niu/jquery-1.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/bootstrap.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/plupload.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/zh_CN.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/ui.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/qiniu.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/highlight.js");
$doc->addScript("components/com_zmaxcdn/libs/7niu/main.js");

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');
$option = JRequest::getCmd('option');

$params = JComponentHelper::getParams("com_zmaxcdn");		
$yourQiNiuDomain = $params->get("domain");
$yourQiNiuDomain = "http://".$yourQiNiuDomain."/";

?>
<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if (task == 'item.cancel' || document.formvalidator.isValid(document.id('item-form')))
		{
			Joomla.submitform(task, document.getElementById('item-form'));
		}
	}
</script>
<form action="<?php echo JRoute::_('index.php?option=com_zmaxcdn&layout=edit&id=')?>" method="post" name="adminForm" class="form-validate" id="item-form"  enctype="multipart/form-data">
<!--------------------------------------------->
	<div class="my_container">
		<div class="text-left col-span-12 wrapper">
			<h1 class="text-left col-span-12 ">
				添加资源到七牛云存储           
			</h1>        
			<ul class="tip col-span-12 text-mute">
				<li>
						系统会在自动将你的文件上传到你指定的七牛空间，并且存储访问该文件的URL。
				</li>
				<li>
					你可以在你的网站上像使用本地文件一样对这些文件进行操作。非常的简单
				</li>
				<li>
					可以支持各种格式的文件，大小不超过1000M都是可以的
				</li>
				<li>
					支持拖动，可以直接将文件拖动到选择文件的按钮上
				</li>
				<li>
					上传图片可查看处理效果[加水印],[缩略图],[旋转]
				</li>
			</ul>
		</div>
		<div class="body">
			<div class="col-span-12">
				<div class="" style="position: relative;" id="container">
					<a style="position: relative; z-index: 1;" class="btn btn-default btn-lg " id="pickfiles" href="#">
						<i class="glyphicon glyphicon-plus"></i>
						<span>选择文件</span>
					</a>
				<div style="position: absolute; top: 0px; left: 0px; width: 167px; height: 46px; overflow: hidden; z-index: 0;" class="moxie-shim moxie-shim-html5" id="html5_19ur01mme1m2c1rc11moo1jlurvv3_container"><input id="html5_19ur01mme1m2c1rc11moo1jlurvv3" style="font-size: 999px; opacity: 0; position: absolute; top: 0px; left: 0px; width: 100%; height: 100%;" multiple="" accept="" type="file"></div></div>
			</div>
			<div style="" id="success" class="col-span-12">            
			</div>
			<div class="col-span-12 ">
				<table class="table table-bordered table-striped table-hover text-left" style="margin-top: 40px;">
					<thead>
					  <tr>
						<th class="span4">文件名</th>
						<th class="span2">大小</th>
						<th class="span6">详情</th>
					  </tr>
					</thead>
					<tbody id="fsUploadProgress">

					</tbody>
				</table>
			</div>
		</div>
		<div class="modal fade body" id="myModal-img" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title" id="myModalLabel">图片效果查看</h4>
			  </div>
			  <div class="modal-body">
				<div class="modal-body-wrapper text-center">
					<a href="" target="_blank">
						<img src="" alt="" data-key="" data-h="">
					</a>
				</div>
				<div class="modal-body-footer">
					<div class="watermark">
						<span>水印控制：</span>
						<a href="#" data-watermark="NorthWest" class="btn btn-default">
							左上角
						</a>
						<a href="#" data-watermark="SouthWest" class="btn btn-default">
							左下角
						</a>
						<a href="#" data-watermark="NorthEast" class="btn btn-default">
							右上角
						</a>
						<a href="#" data-watermark="SouthEast" class="btn btn-default disabled">
							右下角
						</a>
						<a href="#" data-watermark="false" class="btn btn-default">
							无水印
						</a>
					</div>
					 <div class="imageView2">
						<span>缩略控制：</span>
						<a href="#" data-imageview="large" class="btn btn-default disabled">
							大缩略图
						</a>
						<a href="#" data-imageview="middle" class="btn btn-default">
							中缩略图
						</a>
						<a href="#" data-imageview="small" class="btn btn-default">
							小缩略图
						</a>
					</div>
					<div class="imageMogr2">
						<span>高级控制：</span>
						<a href="#" data-imagemogr="left" class="btn btn-default no-disable-click">
							逆时针
						</a>
						<a href="#" data-imagemogr="right" class="btn btn-default no-disable-click">
							顺时针
						</a>
						<a href="#" data-imagemogr="no-rotate" class="btn btn-default">
							无旋转
						</a>
					</div>
					<div class="text-warning">
						备注：小图片水印效果不明显，建议使用大图片预览水印效果
					</div>
				</div>
			  </div>
			  <div class="modal-footer">				
				<button type="button" class="btn btn-primary" data-dismiss="modal">关闭</button>
			  </div>
			</div>
		  </div>
		</div>
	</div>
	
	
<!--------------------------------------------->
	<script type="text/javascript">
		// 添加全局站点信息
		var YOU_QINIU_DOMAIN = '<?php echo $yourQiNiuDomain;?>';	
	</script>	
	
	<div>
		<input type="hidden" name="option" value="<?php echo $option;?>"/>
		<input type="hidden" name="task" value=""/>
		<input type="hidden" name="id" value="" />
		<?php echo JHtml::_('form.token');?>
	</div>
</form>
	
	