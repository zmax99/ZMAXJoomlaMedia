<?php
/**
 *	description:ZMAX CDN品列表模型
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-24
 */


defined('_JEXEC') or die('Restricted Access');

//jimport('joomla.application.component.model');
jimport('joomla.application.component.modellist');

class zmaxcdnModelItems extends JModelList
{
	
	public function __construct($config = array())
	{
		if(empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			'id',
			'title',
			'name',
			'category',
			'size',
			'type',
			'doc_type',
			'date',
			'description',
			'category_id'
			);
			if (JLanguageAssociations::isEnabled())
			{
				$config['filter_fields'][] = 'association';
			}
		}
		parent::__construct($config);
	}
	
	public function getForm( $data = array() , $loadData = true)
	{
		//Get the form
		$form = $this->loadForm('com_zmaxcdn.item' ,'item' ,array('control' =>' jform' ,'load_data' => $loadData ));
		if(!$form)
		{
			return false;
		}
		
		return $form;
	}
	
	protected function getListQuery()
	 {
		$db =  JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select("i.id ,i.catid ,i.uid ,i.name AS title ,i.filename ,i.description ,i.type,i.doc_type,i.size ,i.length ,i.cdn_path ,i.local_path, i.create_date AS date");
		$query->from( '#__zmaxcdn_item AS i' );
		$query->select("c.title AS category");
		$query->leftJoin('#__categories AS c on c.id = i.catid');
		
		/**
		 *  在前台显示，是不用处理用户的
		 */
		//处理用户
		//$user = JFactory::getUser();
		//$query->where("i.uid =".$user->id);
		
		
		//处理文件的分类		
		if ($catid = $this->getState('filter.category_id'))
		{
			$ids = zmaxcdnHelper::getChildCateIds($catid);
			$ids = implode(',',$ids);
			$query->where('catid IN ('.$ids .")" );				
		}
		
		//处理文件的文档类型
		if ($docType = $this->getState('filter.doc_type'))
		{
			$docType = $db->quote($db->escape($docType, true) . '%');
			$query->where('i.doc_type LIKE '. $docType );					
		}
		
		
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			$search = strtolower($search);
			$search = $db->quote('%' . $db->escape($search, true) . '%');
			$query->where('(i.name LIKE ' . $search . ' OR i.description LIKE ' . $search . ' OR i.type LIKE ' . $search . ' OR i.size LIKE ' . $search .')');				
		}
		
		//处理模态对话框中的特殊情况
		$input = JFactory::getApplication()->input;
		$tmpl = $input->get('tmpl');
		if($tmpl =="component")
		{
			$extension = $input->get('extension','com_conent');
			
			$query->where('i.extension = "'. $extension.'"' );
			
			$docType = $input->get('doc_type');
			$docType = trim($docType);
			if($docType)
			{
				$docType = $db->quote($db->escape($docType, true) . '%');
				$query->where('i.doc_type LIKE '. $docType );	
			}
			
			
			
			
			$session = JFactory::getSession();
			$function = $input->get('function','SelectItem1');
			$session->set("zmaxcdn.field.function",$function);
		}
		
		
		//排序
		$orderCol = $this->state->get("list.ordering" ,'id');
		$orderDirn = $this->state->get("list.direction",'desc');
		$query->order($db->escape($orderCol).' '.$db->escape($orderDirn));
		
		//echo $query;
		
		return $query;
		
	 }

}