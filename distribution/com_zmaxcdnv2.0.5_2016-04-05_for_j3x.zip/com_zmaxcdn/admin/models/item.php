<?php
/**
 *	description:ZMAX没听㡵 资源模型文件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-09-06
 */
use Qiniu\Auth;
use Qiniu\Storage\UploadManager;
use Qiniu\Storage\BucketManager;

defined('_JEXEC') or die();
jimport('joomla.application.component.modeladmin');

class zmaxcdnModelItem extends JModelAdmin
{
	public function getForm( $data = array() , $loadData = true)
	{
		//Get the form
		$form = $this->loadForm('com_zmaxcdn.item' ,'item' ,array('control' =>' jform' ,'load_data' => $loadData ));
		if(!$form)
		{
			return false;
		}
		
		return $form;
	}
	
	public function loadFormData()
	{
		//Load form data
		$data = $this->getItem();
		return $data;
	}
	
	public function getItem($pk = null)
	{
		if($item = parent::getItem($pk))
		{
			// Convert the params field to an array.
			$registry = new JRegistry;
			$registry->loadString($item->attr);
			$item->attr = $registry->toArray();

			$registry->loadString($item->image);
			$item->image = $registry->toArray();			
		}
		
		if(!empty($item->id))
		{
			$item->tags = new JHelperTags;
			$item->tags->getTagIds($item->id ,'com_zmaxcdn.item');
		}
		return $item;
	}
	
	public function saveEdit($data)
	{
		if(isset($data["attr"]) && is_array($data["attr"])  )
		{
			$registry = new JRegistry;
			$registry->loadArray($data["attr"]);
			$data["attr"] = (string) $registry;
		}
		
		if(isset($data["image"]) && is_array($data["image"])  )
		{
			$registry = new JRegistry;
			$registry->loadArray($data["image"]);
			$data["image"] = (string) $registry;
		}
		
		return parent::save($data);
	}
	
	public function save($data)
	{		
		$file = $data["files"];
		
		//上传文件
		require(JPATH_COMPONENT_ADMINISTRATOR."/libs/upload/zmUpload.php");
		$uploader = new zmUpload($file);
		$name = $uploader->getFileName();//得到用户上传的文件的名称
		$size = $uploader->getSize();
		$type = $uploader->getFileType();
		$catid = $data["catid"];
		$filename = $uploader->makeName($type ,$catid); //存储在本地服务器上的名称
		
		//重新设置上传后的名称
		$uploader->setFileName($filename);
		$uploader->setPath(JPATH_COMPONENT_ADMINISTRATOR."/source");
		if(!$uploader->doUpload())//开始执行上传
		{
			$this->_message =zmUpload::getWrongMessage(); 
			return false;
		}
		
		$cdn_path ="";
		$params = JComponentHelper::getParams("com_zmaxcdn");
		$enableQiniu = $params->get("enable_qiniu",'0');
		
		if($enableQiniu)
		{
			//上传文件到七牛
			require_once(JPATH_COMPONENT.DS."libs".DS."vendor".DS."autoload.php");
			
			// 设置信息
			$APP_ACCESS_KEY = $params->get("accessKey");
			$APP_SECRET_KEY = $params->get("secretKey");
			$bucket = $params->get("bucket");
			
			//得到一个认证对象
			$auth = new Auth($APP_ACCESS_KEY, $APP_SECRET_KEY);
			$token = $auth->uploadToken($bucket);
			$uploadManager = new UploadManager();
			$uploadFilePath = $uploader->getPath().DS.$uploader->getFileName();
			
			//执行上传 (多次上传同一个文件不会有任何的作用)
			list($ret, $err) = $uploadManager->putFile($token, null, $uploadFilePath);
			if ($err != null) 
			{
				$this->_message = "上传失败。错误消息：".$err->message();
				return false;
			}
			$cdn_path= $ret["key"] ;		
		}
		
		
		
		//存储数据
		$data["cdn_path"]	= $cdn_path;		
		$data['local_path']="/source/".$uploader->getFileName();
		$data["uid"] = JFactory::getUser()->id;
		$data["name"] = $name;
		$data["filename"]=$filename;
		$data['size']=$size;
		$data['type'] = $type;
		$data["create_date"] = $this->getPostDate();
		
		$session = JFactory::getSession();
		$session->set("com_zmaxcdn.item.data" ,json_encode($data));
		return parent::save($data);
	}
	
	//得到提交订单的时间
    public function getPostDate()
	{
		date_default_timezone_set('PRC');
		$date= date("Y-m-d H:i:s");
		$now = JDate::getInstance($date);
		return $now->toSql();
	}
	
	
}


?>