DROP TABLE IF EXISTS `#__zmaxcdn_item`; /*ZMAXCDN 资源表*/
DROP TABLE IF EXISTS `#__zmaxcdn_taggroup`; /*ZMAXCDN 标签组表*/
DROP TABLE IF EXISTS `#__zmaxcdn_upload_config`; /*ZMAXCDN 上传设置表*/



