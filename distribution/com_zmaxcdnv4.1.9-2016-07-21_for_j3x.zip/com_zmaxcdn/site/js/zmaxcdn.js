jQuery(function($) {
	jQuery('#itemlist_controller').click(function() {
		var itemlist = jQuery('#itemlist');
			itemlist.slideToggle();
	});

});

