<?php
/**
 * @package     Joomla.Legacy
 * @subpackage  Form
 *
 * @copyright   Copyright (C) 2005 - 2014 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE
 */

defined('JPATH_PLATFORM') or die;

JFormHelper::loadFieldClass('list');

/**
 * Form Field class for the Joomla Platform.
 * Supports an HTML select list of categories
 *
 * @package     Joomla.Legacy
 * @subpackage  Form
 * @since       11.1
 */
class JFormFieldZmaxcate extends JFormFieldCategory
{
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  11.1
	 */
	public $type = 'Zmaxcate';

	protected function getOptions()
	{
		
		$options = parent::getOptions();
		
		$type = $this->element['catetype'];
		$params = JComponentHelper::getParams("com_zmaxerp");
		$cateId="";
		if($type=="items")
		{
			$cateId = $params->get("items_cateid");
		}
		if($type=="suppliers")
		{
			$cateId = $params->get("suppliers_cateid");
		}
		
		$parent=$cateId;
		$extension = $this->element['extension'] ? (string) $this->element['extension'] : (string) $this->element['scope'];
		if($parent=="")
		{
			return $options;
		}
		
		
		$this->getAllChildrenCate($parent ,$extension,$ids);
		$ids = trim($ids,',');
		$ids = explode(',',$ids);
		
		$newOptions = array();
		foreach($options as $option)
		{
			if(in_array($option->value ,$ids) || $option->value=="")
			{
				$newOptions[]=$option;
			}
		}
		return $newOptions;
		
	}
	
	//判断一个分类是否有子分类
	protected function hasChildrenCate($pId ,$extension,&$childrenObjectList = null)
	{
		if(empty($pId))
		{
			return false;
		}
		
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select("id")->from('#__categories');
		$query->where('parent_id = '.$pId);
		$query->where('extension = ' . $db->quote($extension));
		$db->setQuery($query);
		
		$childrenObjectList = $db->loadObjectList();
		
		if(count($childrenObjectList)== 0)
		{
			return false;
		}
		return true;
	}
	 
	//返回指定分类的所有子分类的id
	 public function getAllChildrenCate($pId,$extension,&$childerId)
	 {
		$childerId=$childerId.$pId.",";
		$childrenList = null;
		if(!$this->hasChildrenCate($pId , $extension,$childrenList))
		{
			return ;
		}		
		//有子分类,遍历子分类 
		foreach($childrenList as $child)
		{
			self::getAllChildrenCate($child->id  , $extension,$childerId);
		}
	 }
}
