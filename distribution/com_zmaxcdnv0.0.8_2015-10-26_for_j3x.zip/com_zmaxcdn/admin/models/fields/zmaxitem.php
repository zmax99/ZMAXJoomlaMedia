<?php
/**
 *	description:ZMAX媒体管理 项目列表模型
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-10-26
 * @license GNU General Public License version 3, or later
 */
 
defined('JPATH_BASE') or die;

class JFormFieldZmaxitem extends JFormField
{
	/**
	 *	The form field type
	 */
	 protected $type="ZmaxItem";
	 
	 /**
	  * Method to get the field input markup.
	  * 
	  * @return string The field input markup
	  */
	  protected function getInput()
	  {
		//Load the modal behavior script
		JHtml::_('behavior.modal' ,'a.modal');
		
		//Build the script
		$script = array();
		$script[] = ' function SelectItem(id ,title ){';
		$script[] = '			document.id("'.$this->id.'_id").value = title;';
		$script[] = '			document.id("'.$this->id.'_name").value = title;';
		$script[] = '			SqueezeBox.close();';
		$script[] = '			}';
		
		// Add the script to the document head
		JFactory::getDocument()->addScriptDeclaration(implode("\n" ,$script));
		
		//Setup variables for display
		$html = array();
		$link = 'index.php?option=com_zmaxcdn&amp;view=items&amp;layout=modal&amp;tmpl=component&amp;function=SelectItem';
		
		$value=$this->value;
		$value = htmlspecialchars($value ,ENT_QUOTES ,'UTF-8');
		
		//The current user display field
		$html[] = '<div class="fltlft">';
		$html[] = ' <input type="text" id="'.$this->id.'_name" value="'.$value.'"disabled="disabled" size="25" />';
		$html[] = '</div>';
		
		// The user select button
		$html[] = '<div class="button2-left">';
		$html[] = ' <div class="blank">';
		$html[] = '		<a class="modal btn" href="'.$link.'&amp;'.JSession::getFormToken().'=1" rel="{handler:\'iframe\',size:{x:800 ,y:450}}" >'.JText::_('选择项目').'</a>';
		$html[] = '	</div>';
		$html[] = '</div>';
		
		

		
		
		// Class='required' for client side validation
		$class='';
		if($this->required)
		{
			$class= ' class="required modal-value"';
		}
		
		$html[]= '<input type="hidden" id="'.$this->id.'_id"'.$class.' name="'.$this->name .'" value="'.$value.'" />';
		return implode("\n" ,$html);
	  }
}