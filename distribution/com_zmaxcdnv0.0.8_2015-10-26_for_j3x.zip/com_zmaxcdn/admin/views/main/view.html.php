<?php 
/**
 *	description:ZMAXCDN 用户导航
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2015-08-25
 */
 
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

class zmaxcdnViewMain extends JViewLegacy
{
     function display($tpl = null)	 
	 {
		$this->addToolBar();
		
		$this->cpInfo = $this->get("ComponentInfo");
		$this->sysInfo = $this->get("SystemInfo");
		if ($this->getLayout() !== 'modal')
		{
			zmaxcdnHelper::addSubmenu('main');
			$this->sidebar = JHtmlSidebar::render();
		}
		
		
		parent::display($tpl);
	 }
	 

	 
	 /**
	  * 设置工具栏
	  * 
	  * @access protected
	  */
	  protected function addToolBar()
	  {
		JToolBarHelper::title(JText::_("ZMAXCDN 控制面板"));
		JToolBarHelper::preferences('com_zmaxcdn');
	  }
	  
}