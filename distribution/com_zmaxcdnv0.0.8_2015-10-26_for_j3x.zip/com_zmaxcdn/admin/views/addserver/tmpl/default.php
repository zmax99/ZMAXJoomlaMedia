<?php 
//加载需要的css ,js
$doc = JFactory::getDocument();
$doc->addStyleSheet("components/com_zmaxcdn/libs/webuploader/webuploader.css");
$doc->addStyleSheet("components/com_zmaxcdn/libs/webuploader/wup.css");
$doc->addStyleSheet("components/com_zmaxcdn/libs/webuploader/style.css");
$doc->addScript("components/com_zmaxcdn/libs/webuploader/jquery-2.1.3.min.js");
$doc->addScript("components/com_zmaxcdn/libs/webuploader/webuploader.min.js");
$doc->addScript("components/com_zmaxcdn/libs/webuploader/wup.js");
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('behavior.keepalive');
$option = JRequest::getCmd('option');

?>
<script type="text/javascript">
	Joomla.submitbutton = function(task)
	{
		if (task == 'item.cancel' || document.formvalidator.isValid(document.id('item-form')))
		{
			Joomla.submitform(task, document.getElementById('item-form'));
		}
	}
</script>
<form action="<?php echo JRoute::_('index.php?option=com_zmaxcdn&layout=edit&id=');?>" method="post" name="adminForm" class="form-validate" id="item-form"  enctype="multipart/form-data">
<!--------------------------------------------->
	
	<div class="page-container">
        <h1 class="text-left col-span-12 ">添加资源到本地服务器</h1>
		<div class="row-fluid">
			<div id="system-message-container" class="j-toggle-main span12">
				<button data-dismiss="alert" class="close" type="button">×</button>
				<div class="alert alert-success">
					<h4 class="alert-heading">说明</h4>
					<ul class="text-mute alert-message">
						<li>
							你可以批量将文件上传到服务器。并且支持中文文件名
						</li>
						<li>
							你可以在你的网站上像使用本地文件一样对这些文件进行操作。非常的简单
						</li>
						<li>
							可以支持各种格式的文件，大小不超过1000M都是可以的
						</li>
						<li>
							支持拖动，可以直接将文件拖动到选择文件的按钮上
						</li>
						<li>
							上传图片可查看处理效果[加水印],[缩略图],[旋转]
						</li>
					</ul>
				</div>
			</div>
			
		</div>
		<div class="info_head">
			<label>请选择分类</label>
			<select	name="catid" id="select_catid" class="itemcate">
				<?php $options = JHtml::_('category.options','com_zmaxcdn',$config = array('filter.published' => array(1),'filter.access' =>array(1)));?>
				<?php echo JHtml::_('select.options',$options,'value','text',"",true);?>
			</select>
		</div>
		
		<div class="wu-example" id="uploader">
			<div class="queueList">
				<div class="placeholder" id="dndArea">
					<div id="filePicker" class="webuploader-container"><div class="webuploader-pick">点击选择图片</div>
						<div >
							<input type="file" name="file" class="webuploader-element-invisible" multiple="multiple" accept="image/*">
						</div>
					</div>
				<p>或将图片或者其他类型文件拖到这里，单次最多可选300个文件</p>
				</div>
			<ul class="filelist"></ul></div>
			<div style="display:none;" class="statusBar">
				<div class="progress" style="display: none;">
					<span class="text">0%</span>
					<span class="percentage" style="width: 0%;"></span>
				</div><div class="info">共0张（0B），已上传0张</div>
				<div class="btns">
					<div id="filePicker2" class="webuploader-container"><div class="webuploader-pick">继续添加</div><div id="rt_rt_19uiu564a1a9r9l16d210ia1dm6" style="position: absolute; top: 0px; left: 0px; width: 1px; height: 1px; overflow: hidden;"><input type="file" name="file" class="webuploader-element-invisible" multiple="multiple" accept="image/*"><label style="opacity: 0; width: 100%; height: 100%; display: block; cursor: pointer; background: rgb(255, 255, 255) none repeat scroll 0% 0%;"></label></div></div><div class="uploadBtn state-pedding">开始上传</div>
				</div>
			</div>
		</div>
    </div>
	<script type="text/javascript">
		// 添加全局站点信息
		var BASE_URL = '<?php echo JURI::root();?>components/com_zmaxcdn/libs/webuploader/';
		var DOMAIN_URL = '<?php echo JURI::root();?>';	
	</script>	
<!--------------------------------------------->
	<div>
		<input type="hidden" name="option" value="<?php echo $option;?>"/>
		<input type="hidden" name="task" value=""/>
		<input type="hidden" name="id" value="" />
		<?php echo JHtml::_('form.token');?>
	</div>
</form>
	
	