<?php
/**
 *	description:ZMAXCDN_INSERTBTN 插件
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2016-05-20
 */

// no direct access
jimport("joomla.filesystem.file");
defined('_JEXEC') or die("you can nont access this file!");

if(JFile::exists(JPATH_ROOT."/administrator/components/com_zmaxcdn/libs/zmaxcdn/config.php"))
{
	require_once(JPATH_ROOT."/administrator/components/com_zmaxcdn/libs/zmaxcdn/config.php");	
}

class plgButtonZmaxcdn_insertbtn extends JPlugin
{
	/**
	 * Constructor
	 *
	 * @access      protected
	 * @param       object  $subject The object to observe
	 * @param       array   $config  An array that holds the plugin configuration
	 * @since       1.5
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}

	/**
	 * Display the button
	 *
	 * @return array A two element array of (imageName, textToInsert)
	 */
	public function onDisplay($name, $asset, $author)
	{
		
		//获得参数
		$configId=$this->params->get('config_id');  //上传配置参数
		$config = zmaxcdnConfigHelper::loadConfig($configId);
		if(!$config)
		{
			$config = zmaxcdnConfigHelper::loadDefaultConfig();
		}
		$config->extension = "com_content";
		
		$function = "SelectItembtn";
		
		$session = JFactory::getSession();		
		$session->set("zmaxcdn.field.config",json_encode($config));
		$session->set("zmaxcdn.field.function",$function);
		$session->set("zmaxcdn.field.task","upload.uploadAndInsert");
		
		
		//设置插入js代码
		$script = array();
		$script[] = ' SITE_URL="'.JUri::root().'"';
		$script[] = ' function '.$function.'(id){';
		$script[] =  '
				jQuery.ajax({
								type:"post",
								url:"index.php?option=com_zmaxcdn&task=upload.insert",
								data:{
										id:id
									},
								cache:false,
								success:function(data){
								if(window.execScript) {
										// 给IE的特殊待遇
										window.execScript(data);
									}
									else {
									// 给其他大部分浏览器用的
									window.eval(data);
									}
									},
								error:function()
								{				
									alert("添加失败，Ajax异常，请联系支持团队：Email:zhang19min88@163.com");
								}		
				});';
		
		$script[] = '			}';
		JFactory::getDocument()->addScriptDeclaration(implode("\n" ,$script));	
		
		
		
		$app = JFactory::getApplication();
		$user = JFactory::getUser();
		$extension = $app->input->get('option');
		

		if ($asset == '')
		{
			$asset = $extension;
		}

		if (	$user->authorise('core.edit', $asset)
			||	$user->authorise('core.create', $asset)
			||	(count($user->getAuthorisedCategories($asset, 'core.create')) > 0)
			||	($user->authorise('core.edit.own', $asset) && $author == $user->id)
			||	(count($user->getAuthorisedCategories($extension, 'core.edit')) > 0)
			||	(count($user->getAuthorisedCategories($extension, 'core.edit.own')) > 0 && $author == $user->id))
		{
			
			$link = 'index.php?option=com_zmaxcdn&amp;view=items&amp;caller=plugin&amp;layout=field&amp;tmpl=component&amp;function='.$function.'&amp;e_name=' . $name . '&amp;asset=' . $asset . '&amp;author=' . $author;
			JHtml::_('behavior.modal');
			$button = new JObject;
			$button->modal = true;
			$button->class = 'btn';
			$button->link = $link;
			$button->text = JText::_('ZMAX插入资源');
			$button->name = 'picture';
			$button->options = "{handler: 'iframe', size: {x: 800, y: 550}}";
			return $button;
		}
		else
		{
			return false;
		}	
	}
}
