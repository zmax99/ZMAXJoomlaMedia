<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Content.loadmodule
 *
 * @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Plug-in to enable loading modules into content (e.g. articles)
 * This uses the {loadmodule} syntax
 *
 * @since  1.5
 */
 include_once(JPATH_ROOT."/administrator/components/com_zmaxcdn/helpers/zmaxcdn.php");
 include_once(JPATH_ROOT."/administrator/components/com_zmaxcdn/libs/zmaxcdn/item.php");
 JHtml::_("jquery.framework");
class PlgContentZmaxplayvideo extends JPlugin
{
	protected static $items = array();
	
	public function __construct($config)
	{
		parent::__construct($config);
		$this->initPlayer();
	}

	/**
	 * Plugin that loads module positions within content
	 *
	 * @param   string   $context   The context of the content being passed to the plugin.
	 * @param   object   &$article  The article object.  Note $article->text is also available
	 * @param   mixed    &$params   The article params
	 * @param   integer  $page      The 'page' number
	 *
	 * @return  mixed   true if there is an error. Void otherwise.
	 *
	 * @since   1.6
	 */
	public function onContentPrepare($context, &$article, &$params, $page = 0)
	{
		// Don't run this plugin when the content is being indexed
		if ($context == 'com_finder.indexer')
		{
			return true;
		}
		
		
		// Expression to search for (positions)
		$regex = '/<a\s.*data-marker="zmax".*?\/a>/i';
		

		// Find all instances of plugin and put in $matches for loadposition
		// $matches[0] is full pattern match, $matches[1] is the position
		//if(!$article->text)
		//{
		//	$article->text = $article->introtext . $article->fulltext;
		//}
		preg_match_all($regex, $article->text, $matches, PREG_SET_ORDER);

		
		
		if($matches)
		{	
			
			$this->addPlayerJs();
			
			foreach ($matches as $match)
			{
				$match = $match[0];
				$dataType = $this->getAttr($match ,"data-type");
				$dataAction = $this->getAttr($match ,"data-action","play");
				if($dataType=="video" && $dataAction=="play")
				{
					//得到资源的ID
					$sourceId = $this->getAttr($match ,"data-id");
					$item = $this->getItemBySource($sourceId);
					if(!$item)
					{
						return true;
					}
					
					$this->setPlayer($item ,$article);
				
					$player="<div class='zmaxplayer' playerId='".$article->id."' ><div id='zmaxcontainer".$article->id."'></div></div>";
					$output=$player;

					$article->text = str_replace($match, $output, $article->text);

				}
	
			}
		}
		return true;
	}
	
	//得到标签的属性
	protected function getAttr($tag ,$attr ,$defaultValue="")
	{
		//STEP 0 将所有属性转化为小写
		$attr = strtolower($attr);
		
		//STEP 1 在字符串中查找属性名
		$attrPos = stripos($tag,$attr);
		if($attrPos===false)
		{
			return $defaultValue;
		}
		
		
		//STEP 2  从属性开始，找到等号 =
		 $startPos = stripos($tag,"=",$attrPos);
		 $startPos =$startPos+2; //往后移动两个位置 ="
		 
		 $endPos = stripos($tag,'"',$startPos); //找到属性值结束的标识 "
		 $attrValue = substr($tag,$startPos ,$endPos - $startPos); 
		 
		 return $attrValue; 
	}
	protected function addPlayerJs()
	{
		$doc = JFactory::getDocument();
		$doc->addScript("plugins/content/zmaxplayvideo/jwplayer/jwplayer.js");
		$doc->addScript("plugins/content/zmaxplayvideo/jwplayer/k.js");
		$doc->addScript("plugins/content/zmaxplayvideo/jwplayer/jwplayer.html5.js");
		$doc->addScript("plugins/content/zmaxplayvideo/jwplayer/jwpsrv.js");
	}
	
	protected function initPlayer()
	{
		
		$doc = JFactory::getDocument();
		$script=array();		
		$script[]= 'var gThePlayers=new Array();';
		$script[]= 'var rate=16/9; ';
		
		$doc->addScriptDeclaration(implode("",$script));
	}
	
	protected function setPlayer($item ,$article=null)
	{
		
		$doc = JFactory::getDocument();
		$jwpPath = JUri::root()."plugins/content/zmaxplayvideo/jwplayer/";
		$flashPath = JUri::root()."plugins/content/zmaxplayvideo/jwplayer/jwplayer.flash.swf";
		
		$image = json_decode($item->image);
		@$imagePath = $image->image_intro;
		
		$file = zmaxcdnItemHelper::getItemUrl($item);
		
		
		$script=array();	
		$script[]= 'jQuery(function() {  
				
				var width=jQuery("#zmaxcontainer'.$article->id.'").width();		
				var height=width/rate;
				if(height==0)
				{
					height=460;
				}
				
				thePlayer = jwplayer("zmaxcontainer'.$article->id.'").setup({  
				flashplayer: "'.$flashPath.'", 
				logo:{
					file:"",
					link:"http://www.zmax99.com",
					position:"top-right"
				},
				skin:"",
				aboutlink:"http://www.zmax99.com",
				abouttext:"ZMAX团队",
				file:"'.$file.'",
				image: "'.$imagePath.'" ,//视频预览图片			
				width:"95%",
				height:height,
				bufferlength:"1",				
				dock: "false"  
				}); 
				 var player = new Array();
				 player["id"]='.$article->id.';
				 player["player"]=thePlayer;
				
				//gThePlayers.push(thePlayer'.$article->id.');
				gThePlayers.push(player);
			});';
			
		$doc->addScriptDeclaration(implode("",$script));
	}
	
	public function getItemBySource($id)
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select("*")->from("#__zmaxcdn_item")->where("id='".$id."'");
		$db->setQuery($query);
		$item = $db->loadObject();
		return $item;
	}
}
