<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Content.loadmodule
 *
 * @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * Plug-in to enable loading modules into content (e.g. articles)
 * This uses the {loadmodule} syntax
 *
 * @since  1.5
 */
 JHtml::_("jquery.framework");
 include_once(JPATH_ROOT."/administrator/components/com_zmaxcdn/helpers/zmaxcdn.php");
 include_once(JPATH_ROOT."/administrator/components/com_zmaxcdn/libs/zmaxcdn/item.php");
class PlgContentZmaxdownload extends JPlugin
{
	protected static $items = array();
	
	public function __construct($config)
	{
		parent::__construct($config);		
	}

	/**
	 * Plugin that loads module positions within content
	 *
	 * @param   string   $context   The context of the content being passed to the plugin.
	 * @param   object   &$article  The article object.  Note $article->text is also available
	 * @param   mixed    &$params   The article params
	 * @param   integer  $page      The 'page' number
	 *
	 * @return  mixed   true if there is an error. Void otherwise.
	 *
	 * @since   1.6
	 */
	public function onContentPrepare($context, &$article, &$params, $page = 0)
	{
		// Don't run this plugin when the content is being indexed
		if ($context == 'com_finder.indexer')
		{
			return true;
		}
		
		
		// Expression to search for (positions)
		$regex = '/<a\s.*data-marker="zmax".*?\/a>/i';
		

		// Find all instances of plugin and put in $matches for loadposition
		// $matches[0] is full pattern match, $matches[1] is the position
		//if(!$article->text)
		//{
		//	$article->text = $article->introtext . $article->fulltext;
		//}
		preg_match_all($regex, $article->text, $matches, PREG_SET_ORDER);

		$doc = JFactory::getDocument();
		$doc->addScript("components/com_zmaxcdn/js/zmaxcdn_download.js");
		
		if($matches)
		{	
			foreach ($matches as $match)
			{
				$match = $match[0];
				$dataType = $this->getAttr($match ,"data-type");
				$dataAction = $this->getAttr($match ,"data-action","download");
				if($dataType=="package" || $dataAction=="download")
				{
					//得到资源的ID
					$sourceId = $this->getAttr($match ,"data-id");
					$item = $this->getItemBySource($sourceId);
					
					if(!$item)
					{
						return true;
					}
					
					$downloadLink='<a href="#" class="zmaxpackage" data-id="'.$item->id.'" >'.$item->name.'</a>';
					$output=$downloadLink;					
					$article->text = str_replace($match, $output, $article->text);

				}
	
			}
		}
		return true;
	}
	
	//得到标签的属性
	protected function getAttr($tag ,$attr ,$defaultValue="")
	{
		//STEP 0 将所有属性转化为小写
		$attr = strtolower($attr);
		
		//STEP 1 在字符串中查找属性名
		$attrPos = stripos($tag,$attr);
		if($attrPos===false)
		{
			return $defaultValue;
		}
		
		
		//STEP 2  从属性开始，找到等号 =
		 $startPos = stripos($tag,"=",$attrPos);
		 $startPos =$startPos+2; //往后移动两个位置 ="
		 
		 $endPos = stripos($tag,'"',$startPos); //找到属性值结束的标识 "
		 $attrValue = substr($tag,$startPos ,$endPos - $startPos); 
		 
		 return $attrValue; 
	}
	
	
	public function getItemBySource($id)
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select("*")->from("#__zmaxcdn_item")->where("id='".$id."'");
		$db->setQuery($query);
		$item = $db->loadObject();
		return $item;
	}
}
